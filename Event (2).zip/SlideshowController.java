import javax.swing.ImageIcon;
import javax.swing.Timer;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

public class SlideshowController {
    private EventSlider slider;
    private EventLoader eventLoader;
    private Timer timer;
    private int currentEventIndex = 0;
    private List<String> eventDescriptions; // 이벤트 설명을 관리하는 리스트

    public SlideshowController(EventSlider slider, EventLoader eventLoader) {
        this.slider = slider;
        this.eventLoader = eventLoader;
        this.eventDescriptions = eventLoader.getEventDescriptions(); // 이벤트 설명 초기화
    }

    public void loadEvent(int index) {
        ImageIcon resizedIcon = eventLoader.loadEvent(index);
        slider.updateImageLabel(resizedIcon);
    }

    public void startSlideshow() {
        if (timer == null) {
            timer = new Timer(2000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    currentEventIndex = (currentEventIndex + 1) % eventLoader.getEventPaths().length;
                    loadEvent(currentEventIndex);
                }
            });
            timer.start();
        }
    }

    public void stopSlideshow() {
        if (timer != null) {
            timer.stop();
            timer = null;
        }
    }

    public void nextEvent() {
        currentEventIndex = (currentEventIndex + 1) % eventLoader.getEventPaths().length;
        loadEvent(currentEventIndex);
        // 이미지 전환 후 설명 표시는 클릭 이벤트 핸들러에서 처리하도록 변경
    }

    public void previousEvent() {
        currentEventIndex = (currentEventIndex - 1 + eventLoader.getEventPaths().length) % eventLoader.getEventPaths().length;
        loadEvent(currentEventIndex);
        // 이미지 전환 후 설명 표시는 클릭 이벤트 핸들러에서 처리하도록 변경
    }

    public int getCurrentEventIndex() {
        return currentEventIndex;
    }

    public String getEventDescription(int index) {
        return eventDescriptions.get(index);
    }
}
