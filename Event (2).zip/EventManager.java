import java.util.ArrayList;
import java.util.List;

public class EventManager {
    private List<Event> events;

    public EventManager() {
        events = new ArrayList<>();
        events.add(new Event("../Images/event1.jpg", 1000, 500, "행사 장소: 1층\n행사 시간: 10:00~14:00"));
        events.add(new Event("../Images/event2.jpg", 1000, 500, "행사 장소: 2층\n행사 시간: 11:00~15:00"));
        events.add(new Event("../Images/event3.jpg", 1000, 500, "행사 장소: 3층\n행사 시간: 11:00~15:00"));
    }

    public List<Event> getEvents() {
        return events;
    }

    public Event getEvent(int index) {
        return events.get(index);
    }

    public String[] getEventPaths() {
        String[] paths = new String[events.size()];
        for (int i = 0; i < events.size(); i++) {
            paths[i] = events.get(i).getPath();
        }
        return paths;
    }

    public List<String> getEventDescriptions() {
        List<String> descriptions = new ArrayList<>();
        for (Event event : events) {
            descriptions.add(event.getDescription());
        }
        return descriptions;
    }

    public void updateEvent(int index, String path, String description) {
        Event event = events.get(index);
        event.setPath(path);
        event.setDescription(description);
    }
}
