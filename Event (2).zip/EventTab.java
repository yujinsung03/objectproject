import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EventTab extends JFrame implements ActionListener {

    private ImageIcon imageIcon;
    private String eventDescription;

    public EventTab(String eventDescription) {
        this.imageIcon = imageIcon;
        this.eventDescription = eventDescription;

        setTitle("Event Popup");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(400, 300);
        setLayout(new BorderLayout());

        JLabel imageLabel = new JLabel(imageIcon);
        add(imageLabel, BorderLayout.CENTER);

        JLabel eventInfoLabel = new JLabel("<html><center>" + eventDescription + "</center></html>");
        eventInfoLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        eventInfoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(eventInfoLabel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }
	
    @Override
    public void actionPerformed(ActionEvent e) {
    }
}
