package 객체지향기말최종1;

import javax.swing.*;
import java.awt.*;

public class Menubuttonpanelmain {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Example Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000, 1000); 

        Menubuttonpanel panelCreator = new Menubuttonpanel();
        JPanel panel = panelCreator.createPanel();  

        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.EAST); 

        frame.setVisible(true);
    }
}