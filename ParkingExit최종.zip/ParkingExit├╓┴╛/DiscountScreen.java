package 객체지향기말최종1;

import javax.swing.*;
import java.awt.*;


public class DiscountScreen {
    private JFrame frame;

    public void showScreen() {
        if (frame == null) {
            frame = new JFrame("주차할인 정보");
            frame.setSize(1000, 600);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
            frame.setLayout(null); 
            frame.setLocationRelativeTo(null);
            
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBounds(0, 0, 1000, 600);
            
            JLabel titleLabel = new JLabel("주차할인 정보");
            titleLabel.setBounds(100, 50, 200, 30); // 제목의 위치와 크기 설정
            
            titleLabel.setFont(new Font("돋움", Font.BOLD, 24));
            panel.add(titleLabel);

            JLabel feeLabel = new JLabel("기본요금: 2,000원/시간");
            feeLabel.setBounds(400, 100, 200, 30); // 기본요금의 위치와 크기 설정
            feeLabel.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            panel.add(feeLabel);

            JButton closeButton = new JButton("나가기");
            closeButton.setBounds(400, 500, 200, 30);
            closeButton.addActionListener(e -> {
                closeScreen();
            });
            panel.add(closeButton);

            frame.add(panel);
            frame.setVisible(true);
        } else {
            frame.setVisible(true); // 이미 존재하는 경우 화면을 보이게 함
        }
    }

    public void closeScreen() {
        frame.dispose(); // 화면을 닫음
    }
}


