package 객체지향기말최종1;

public class Main {
    public static void main(String[] args) {
    	
        ParkingExit.start();
    }
}
