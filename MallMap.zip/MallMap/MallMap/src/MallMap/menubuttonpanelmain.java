package MallMap;

import javax.swing.*;
import java.awt.*;

public class menubuttonpanelmain {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Example Frame");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000, 1000); 

        menubuttonpanel panelCreator = new menubuttonpanel();
        JPanel panel = panelCreator.createPanel();  

        frame.setLayout(new BorderLayout());
        frame.add(panel, BorderLayout.EAST); 

        frame.setVisible(true);
    }
}