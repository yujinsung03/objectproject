package MallMap;
import java.awt.*;
import javax.swing.*;
import java.util.Calendar;

class TimerThread extends Thread {
	JLabel timerLabel;

	public TimerThread(JLabel Label) {
		timerLabel = Label;
	}

	public void run() {
		while(true) {
			Calendar time = Calendar.getInstance();
			int hh = time.get(Calendar.HOUR_OF_DAY);
			int mi = time.get(Calendar.MINUTE);
			int sec = time.get(Calendar.SECOND);
			
			timerLabel.setText(String.format("%02d시 %02d분 %02d초", hh, mi, sec));

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}
