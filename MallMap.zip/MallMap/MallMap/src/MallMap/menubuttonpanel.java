package MallMap;
import javax.swing.*;
import java.awt.*;
import java.util.Calendar;

public class menubuttonpanel {
	public JPanel createPanel() {
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(250, 1000));
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setLayout(null);

		JLabel mallLabel = new JLabel("MALL", JLabel.CENTER);
		mallLabel.setForeground(Color.WHITE);
		mallLabel.setBackground(Color.GRAY);
		mallLabel.setOpaque(true);
		mallLabel.setBounds(0, 50, 250, 100);
		mallLabel.setFont(new Font("Arial", Font.BOLD, 65));
		panel.add(mallLabel);

		JButton floorButton = new JButton("층별 안내");
		JButton storeButton = new JButton("매장 안내");
		JButton parkingButton = new JButton("주차 안내");
		JButton eventButton = new JButton("이벤트");

		floorButton.setBounds(50, 300, 150, 50);
		storeButton.setBounds(50, 400, 150, 50);
		parkingButton.setBounds(50, 500, 150, 50);
		eventButton.setBounds(50, 600, 150, 50);

		panel.add(floorButton);
		panel.add(storeButton);
		panel.add(parkingButton);
		panel.add(eventButton);

		JLabel timerLabel = new JLabel("", JLabel.CENTER);
		timerLabel.setFont(new Font("맑은고딕", Font.BOLD, 25));
		timerLabel.setForeground(Color.BLACK);
		timerLabel.setBounds(30, 180, 190, 50);
		panel.add(timerLabel);

		TimerThread timerThread = new TimerThread(timerLabel);
		timerThread.start();

		return panel;

	}
}