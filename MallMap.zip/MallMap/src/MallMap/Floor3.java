package MallMap;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Floor3 extends JFrame {
    private CardLayout cardLayout;
    JPanel mainPanel3;
    private JPanel buttonPanel;
    private JButton btnFirstFloor, btnSecondFloor, btnThirdFloor;
    private JButton btnRestroom, btnStorage;
    Timer blinkTimer;
    boolean isBlinkingRestroom = false;
    boolean isBlinkingStorage = false;

    public Floor3() {
        setTitle("Floor3");
        setSize(2000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel headerLabel = new JLabel("Third Floor", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(headerLabel, BorderLayout.NORTH);

        cardLayout = new CardLayout();
        mainPanel3 = new JPanel(cardLayout);

        JPanel mapPanel = createMapPanel();
        mainPanel3.add(mapPanel, "Map");

        addStorePanels();
        mainPanel3.add(createFirstFloorPanel(), "First Floor");

        add(mainPanel3, BorderLayout.CENTER);
        add(createFloorNavigationPanel(), BorderLayout.SOUTH);

        buttonPanel = new JPanel();
        btnFirstFloor = new JButton("1층");
        btnSecondFloor = new JButton("2층");
        btnThirdFloor = new JButton("3층");
        JButton restroomLocation = new JButton("화장실 위치 안내");
        JButton boxLocation = new JButton("물품보관함 위치 안내");

        btnFirstFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Floor1().setVisible(true);
            }
        });

        btnSecondFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Floor2().setVisible(true);
            }
        });

        btnThirdFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Floor3().setVisible(true);
            }
        });

        restroomLocation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startBlinking(btnRestroom, 7);
            }
        });

        boxLocation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startBlinking(btnStorage, 7);
            }
        });

        buttonPanel.add(btnFirstFloor);
        buttonPanel.add(btnSecondFloor);
        buttonPanel.add(btnThirdFloor);
        buttonPanel.add(restroomLocation);
        buttonPanel.add(boxLocation);

        add(buttonPanel, BorderLayout.SOUTH);
        cardLayout.show(mainPanel3, "Map");
    }
    private JPanel createMapPanel() {
        JPanel mapPanel = new JPanel();
        mapPanel.setLayout(null); // Use absolute positioning for custom layout

        // Create buttons for each store
        int buttonSize = 150; // Increased button size
        int spacing = 150; // Adjust spacing
        int offsetX = 300; // Move to the right
        int offsetY = 100; // Move down

        JButton btnZioDano = createCustomButton("지오다노");
        btnZioDano.setBounds(offsetX, offsetY, buttonSize, buttonSize);
        btnZioDano.addActionListener(new StoreButtonListener("ziorDano"));
        applyRollOverEffect(btnZioDano); // Apply dramatic effect
        mapPanel.add(btnZioDano);

        JButton btnCarhartt = createCustomButton("칼하트");
        btnCarhartt.setBounds(offsetX, offsetY + spacing, buttonSize, buttonSize);
        btnCarhartt.addActionListener(new StoreButtonListener("Carhartt"));
        applyRollOverEffect(btnCarhartt); // Apply dramatic effect
        mapPanel.add(btnCarhartt);

        JButton btnSpao = createCustomButton("스파오");
        btnSpao.setBounds(offsetX, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnSpao.addActionListener(new StoreButtonListener("Spao"));
        applyRollOverEffect(btnSpao); // Apply dramatic effect
        mapPanel.add(btnSpao);

        JButton btnVans = createCustomButton("반스");
        btnVans.setBounds(offsetX + spacing, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnVans.addActionListener(new StoreButtonListener("Vans"));
        applyRollOverEffect(btnVans); // Apply dramatic effect
        mapPanel.add(btnVans);

        JButton btnBind = createCustomButton("바인드");
        btnBind.setBounds(offsetX + 2 * spacing, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnBind.addActionListener(new StoreButtonListener("Bind"));
        applyRollOverEffect(btnBind); // Apply dramatic effect
        mapPanel.add(btnBind);

        JButton btnCovernat = createCustomButton("커버낫");
        btnCovernat.setBounds(offsetX + 3 * spacing, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnCovernat.addActionListener(new StoreButtonListener("Covernat"));
        applyRollOverEffect(btnCovernat); // Apply dramatic effect
        mapPanel.add(btnCovernat);

        JButton btnUniqlo = createCustomButton("유니클로");
        btnUniqlo.setBounds(offsetX + 2 * spacing, offsetY, buttonSize, buttonSize);
        btnUniqlo.addActionListener(new StoreButtonListener("Uniqlo"));
        applyRollOverEffect(btnUniqlo); // Apply dramatic effect
        mapPanel.add(btnUniqlo);

        JButton btnCharlesAndKeith = createCustomButton("찰스앤키스");
        btnCharlesAndKeith.setBounds(offsetX + 3 * spacing, offsetY, buttonSize, buttonSize);
        btnCharlesAndKeith.addActionListener(new StoreButtonListener("CharlesAndKeith"));
        applyRollOverEffect(btnCharlesAndKeith); // Apply dramatic effect
        mapPanel.add(btnCharlesAndKeith);

        btnRestroom = createCustomButton("🚻");
        btnRestroom.setBounds(offsetX + 4 * spacing, offsetY, 75, buttonSize); // Adjusted restroom size
        Font buttonFont = btnRestroom.getFont();
        Font newFont = new Font(buttonFont.getName(), buttonFont.getStyle(), 40);
        btnRestroom.setFont(newFont);
        btnRestroom.addActionListener(new StoreButtonListener("Restroom"));
        applyRollOverEffect(btnRestroom);
        mapPanel.add(btnRestroom);
        
        // Draw lines to separate the buttons
        int lineThickness = 15; // Increased line thickness
        mapPanel.add(createSeparator(offsetX, offsetY + buttonSize, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX, offsetY + buttonSize + spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + spacing, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 2 * spacing, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 3 * spacing, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 2 * spacing, offsetY + buttonSize, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 3 * spacing, offsetY + buttonSize, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 4 * spacing, offsetY + buttonSize, 50, lineThickness));

        return mapPanel;
    }


    private JPanel createFloorNavigationPanel() {
        JPanel floorNavPanel = new JPanel();
        JButton firstFloorBtn = new JButton("1층");
        JButton secondFloorBtn = new JButton("2층");
        JButton thirdFloorBtn = new JButton("3층");

        firstFloorBtn.addActionListener(e -> new Floor1().setVisible(true));
        secondFloorBtn.addActionListener(e -> new Floor2().setVisible(true));
        thirdFloorBtn.addActionListener(e -> new Floor3().setVisible(true));

        floorNavPanel.add(firstFloorBtn);
        floorNavPanel.add(secondFloorBtn);
        floorNavPanel.add(thirdFloorBtn);

        return floorNavPanel;
    }

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setContentAreaFilled(true);
        button.setBackground(Color.WHITE);
        return button;
    }

    private void applyRollOverEffect(JButton button) {
        button.addMouseListener(new ButtonEvent(button));
    }

    private JLabel createSeparator(int x, int y, int width, int height) {
        JLabel separator = new JLabel();
        separator.setOpaque(true);
        separator.setBackground(Color.BLACK);
        separator.setBounds(x, y, width, height);
        return separator;
    }

    
    
    //물품보관함 및 화장실 위치 블링킹효과들 함수
    private void startBlinking(JButton button, int numBlinks) {
        blinkTimer = new Timer(500, new ActionListener() {
            private int count = 0;
            private boolean isVisible = true;

            @Override
            public void actionPerformed(ActionEvent e) {
                button.setVisible(isVisible);
                isVisible = !isVisible;
                count++;
                if (count >= numBlinks) {
                    button.setVisible(true);
                    blinkTimer.stop();
                }
            }
        });
        blinkTimer.start();
    }

    private void stopBlinking() {
        if (blinkTimer != null && blinkTimer.isRunning()) {
            blinkTimer.stop();
            btnRestroom.setVisible(true); // Ensure button is visible after stopping
        }
    }

    private class StoreButtonListener implements ActionListener {
        private String storeName;

        public StoreButtonListener(String storeName) {
            this.storeName = storeName;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if ("Restroom".equals(storeName)) {
                if (!isBlinkingRestroom) {
                    startBlinking(btnRestroom, 5); // Start blinking for 5 times
                } else {
                    stopBlinking();
                }
                isBlinkingRestroom = !isBlinkingRestroom;
            } else if ("Storage".equals(storeName)) {
                if (!isBlinkingStorage) {
                    startBlinking(btnStorage, 5); // Start blinking for 5 times
                } else {
                    stopBlinking();
                }
                isBlinkingStorage = !isBlinkingStorage;
            } else {
                cardLayout.show(mainPanel3, storeName);
            }
        }
    }





    private class ButtonEvent extends MouseAdapter {
        JButton button;

        public ButtonEvent(JButton button) {
            this.button = button;
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            button.setBackground(Color.LIGHT_GRAY);
        }

        @Override
        public void mouseExited(MouseEvent e) {
            button.setBackground(Color.WHITE);
        }
    }

    private JPanel createFirstFloorPanel() {
        JPanel panel = new JPanel();
        panel.add(new JLabel("First Floor"));
        return panel;
    }

    private void addStorePanels() {

 	   ImageIcon ziorImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel1(ziorImage, "ziorDano"), "ziorDano");
   
 	   ImageIcon carharttImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel2(carharttImage, "This is 칼하트 store."), "Carhartt");
 	   
 	   ImageIcon spaoImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel3(spaoImage, "This is SPAO store."), "Spao");
 	   
 	   ImageIcon vansImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel4(vansImage, "This is 반스 store."), "Vans");
 	   
 	   ImageIcon bindImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel5(bindImage, "This is 바인드 store."), "Bind");
 	   
 	   ImageIcon covernatImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel6(covernatImage, "This is 커버낫 store."), "Covernat");
 	   
 	   ImageIcon uniImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel7(uniImage, "This is 유r45니클로 store."), "Uniqlo");
 	   
 	   ImageIcon charImage = new ImageIcon("/Users/choijiwon/Desktop/3-1 OOP/mapTest/mapTest/src/img/restroom.png");
 	  mainPanel3.add(createStorePanel8(charImage, "This is 찰스앤키스 store."), "CharlesAndKeith");
 	   
 }

 private JPanel createStorePanel1(ImageIcon restroomImage, String str1) {
     JPanel panel = new JPanel();
     panel.add(new JLabel(restroomImage));
     return panel;
 }
 private JPanel createStorePanel2(ImageIcon carharttImage, String str2) {
     JPanel panel = new JPanel();
     panel.add(new JLabel(carharttImage));
     return panel;
 }
 private JPanel createStorePanel3(ImageIcon spaoImage, String str3) {
     JPanel panel = new JPanel();
     panel.add(new JLabel(spaoImage));
     return panel;
 }
 private JPanel createStorePanel4(ImageIcon vansImage, String str4) {
     JPanel panel = new JPanel();
     panel.add(new JLabel(vansImage));
     return panel;
 }
 private JPanel createStorePanel5(ImageIcon bindImage, String str5) {
     JPanel panel = new JPanel();
     panel.add(new JLabel(bindImage));
     return panel;
 }
 private JPanel createStorePanel6(ImageIcon covernatImage, String str6) {
     JPanel panel = new JPanel();
     panel.add(new JLabel(covernatImage));
     return panel;
 }
 private JPanel createStorePanel7(ImageIcon  uniImage, String str7) {
     JPanel panel = new JPanel();
     panel.add(new JLabel( uniImage));
     return panel;
 }
 private JPanel createStorePanel8(ImageIcon  charImage, String str7) {
     JPanel panel = new JPanel();
     panel.add(new JLabel( charImage));
     return panel;
 }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Floor1 floor1 = new Floor1();
            floor1.setVisible(true);
        });
    }

}


