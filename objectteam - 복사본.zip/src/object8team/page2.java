package object8team;

class page2 {
	public static void main(String[] args) {
		page2frame ls = new page2frame();
	}
}
