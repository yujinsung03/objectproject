package object8team;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class page2panel14 extends JPanel {
	private page2frame frame;
	ImageIcon img;
	JButton b1 = new JButton("매장 설명");
	JButton b2 = new JButton("약도");
	JLabel label = new JLabel("    슈펜");	
	static int clickCount;
	
	public page2panel14(page2frame frame) {	
		this.frame = frame;
		label.setBounds(0, 220, 234, 50);
		label.setBackground(Color.lightGray);
		label.setOpaque(true);
		add(label);
		
		img = new ImageIcon("Shoppen.jpg");
		JLabel imgLabel = new JLabel(img);
		imgLabel.setBounds(0, 0, 234, 234);
		add(imgLabel);
		
		setLayout(null);
		
		b1.setBounds(0, 270, 130, 30);
		b2.setBounds(130, 270, 104, 30);
		
		styleButton(b1);
		styleButton(b2);
		
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
				clickCount++;
				frame.stores();
				showPanel();
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clickCount++;
                frame.stores();
            }
        });
		
		add(b1);
		add(b2);
		
		setBounds(0, 0, img.getIconWidth(), img.getIconHeight() + 50);
		setVisible(true);
	}
	
	private void styleButton(JButton button) {
		button.setBackground(Color.GRAY);
		button.setForeground(Color.WHITE);
		button.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2));
	}
	
	private void showPanel() {
		JPanel panel = new Shoopen((secondpage)frame.panel2);
		panel.setBounds(200, 100, 850, 550); // 패널 크기와 위치 설정
		
		// firstpage 패널에 nike 패널 추가
		frame.panel2.add(panel, 0);
		frame.panel2.revalidate();
		frame.panel2.repaint();
    }
}
