package object8team;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class thirdpage extends JPanel{

    public thirdpage(page2frame frame) {
        setLayout(null);
        setOpaque(false);

        JButton prevPageButton = new JButton("<");
        prevPageButton.setBounds(5, 350, 50, 50); // 버튼 위치와 크기 설정
        prevPageButton.addActionListener(e -> frame.showSecondPage());
        add(prevPageButton);
        
        JPanel panel = new page2panel18(frame);
        panel.setBounds(70, 50, 234, 300);

        JPanel panel2 = new page2panel19(frame);
        panel2.setBounds(330, 50, 234, 300);

        JPanel panel3 = new page2panel20(frame);
        panel3.setBounds(590, 50, 234, 300);

        JPanel panel4 = new page2panel21(frame);
        panel4.setBounds(850, 50, 234, 300);

        JPanel panel5 = new page2panel22(frame);
        panel5.setBounds(70, 400, 234, 300);

        JPanel panel6 = new page2panel23(frame);
        panel6.setBounds(330, 400, 234, 300);

        JPanel panel7 = new page2panel24(frame);
        panel7.setBounds(590, 400, 234, 310);

        JPanel panel8 = new page2panel25(frame);
        panel8.setBounds(850, 400, 234, 310);

        setVisible(true);
        
        add(panel);
        add(panel2);
        add(panel3);
        add(panel4);
        add(panel5);
        add(panel6);
        add(panel7);
        add(panel8);

    }
}