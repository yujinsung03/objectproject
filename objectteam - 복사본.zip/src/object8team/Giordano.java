package object8team;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Giordano extends JPanel {
    JLabel label = new JLabel("<html>위치: 3층<br><br>영업시간: 12:00 ~ 21:00</html>");
	JButton exitB = new JButton("X");
    private thirdpage parentPanel;
	
	public Giordano(thirdpage parentPanel) {
		this.parentPanel = parentPanel;
		
		setBackground(Color.LIGHT_GRAY);
        setBorder(BorderFactory.createLineBorder(Color.GRAY, 3));
		setLayout(null);
		
		ImageIcon img = new ImageIcon("Giordano.jpg");
		JLabel imgLabel = new JLabel(img);
		imgLabel.setBounds(80, 150, 200, 234);
		add(imgLabel);
		
		label.setFont(new Font("나눔 고딕", Font.BOLD, 20));
		
		label.setBounds(300, 100, 600, 300);
		exitB.setBounds(10, 10, 50, 50);
		
		
		
		add(label);
		add(exitB);
		setVisible(true);

	exitB.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
				parentPanel.remove(Giordano.this);
				// 부모 컴포넌트를 다시 그려서 변경 사항 반영
				parentPanel.revalidate();
				parentPanel.repaint();
			}
	});
}
}

/*add(new BindPanel(), "바인드");*/