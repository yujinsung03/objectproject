package object8team;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.awt.CardLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class page2frame extends JFrame {
	CardLayout cardLayout;
	JPanel mainPanel;
	JPanel panel1;
	JPanel panel2;
	JPanel panel3;
	JPanel leftPanel;
	
    public page2frame() {
        setSize(2000, 1000);
        setTitle("page222");
        setLayout(null);
        
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        JLabel store = new JLabel("지금 뜨는 매장");
        store.setFont(new Font("나눔 고딕", Font.BOLD, 20));
        store.setBounds(10, 30, 150, 50);
        add(store);
        
        leftPanel = new JPanel();
        leftPanel.setBounds(10, 70, 130, 600);
        leftPanel.setOpaque(false);
        add(leftPanel);   
        
        panel1 = new firstpage(this);
        panel2 = new secondpage(this);
        panel3 = new thirdpage(this);
        
        mainPanel.add(panel1, "firstpage");
        mainPanel.add(panel2, "secondpage");
        mainPanel.add(panel3, "thirdpage");        
        mainPanel.setBounds(150, 0, 2000, 700);
        add(mainPanel);
        
        //초성 버튼들
        JButton j1 = new JButton("ㄱ");        
    	JButton j2 = new JButton("ㄴ");
    	JButton j3 = new JButton("ㄷ");
    	JButton j4 = new JButton("ㄹ");
    	JButton j5 = new JButton("ㅁ");
    	JButton j6 = new JButton("ㅂ");
    	JButton j7 = new JButton("ㅅ");
    	JButton j8 = new JButton("ㅇ");
    	JButton j9 = new JButton("ㅈ");
    	JButton j10 = new JButton("ㅊ");
    	JButton j11 = new JButton("ㅋ");
    	JButton j12 = new JButton("ㅌ");
    	JButton j13 = new JButton("ㅍ");
    	JButton j14 = new JButton("ㅎ");
    	
    	styleButton(j1);
		styleButton(j2);
		styleButton(j3);
		styleButton(j4);
		styleButton(j5);
		styleButton(j6);
		styleButton(j7);
		styleButton(j8);
		styleButton(j9);
		styleButton(j10);
		styleButton(j11);
		styleButton(j12);
		styleButton(j13);
		styleButton(j14);
		
		j1.setBounds(250, 740, 50, 50);
		j2.setBounds(320, 740, 50, 50);
		j3.setBounds(390, 740, 50, 50);
		j4.setBounds(460, 740, 50, 50);
		j5.setBounds(530, 740, 50, 50);
		j6.setBounds(600, 740, 50, 50);
		j7.setBounds(670, 740, 50, 50);
		j8.setBounds(740, 740, 50, 50);
		j9.setBounds(810, 740, 50, 50);
		j10.setBounds(880, 740, 50, 50);
		j11.setBounds(950, 740, 50, 50);
		j12.setBounds(1020, 740, 50, 50);
		j13.setBounds(1090, 740, 50, 50);
		j14.setBounds(1160, 740, 50, 50);
		
	    j1.addActionListener(e -> showFirstPage());
	    j2.addActionListener(e -> showFirstPage());
	    j3.addActionListener(e -> showFirstPage());
	    j4.addActionListener(e -> showFirstPage());
	    j5.addActionListener(e -> showFirstPage());
	    j5.addActionListener(e -> showFirstPage());
	    j6.addActionListener(e -> showSecondPage());
	    j7.addActionListener(e -> showSecondPage());
	    j8.addActionListener(e -> showSecondPage());
	    j9.addActionListener(e -> showThirdPage());
	    j10.addActionListener(e -> showThirdPage());
	    j11.addActionListener(e -> showThirdPage());
	    j12.addActionListener(e -> showThirdPage());
	    j13.addActionListener(e -> showThirdPage());
	    j14.addActionListener(e -> showThirdPage());
		
	
		add(j1);
		add(j2);
		add(j3);
		add(j4);
		add(j5);
		add(j6);
		add(j7);
		add(j8);
		add(j9);
		add(j10);
		add(j11);
		add(j12);
		add(j13);
		add(j14);
		
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		setVisible(true);
		

    }
    	// 버튼 스타일 설정 메서드
    	private void styleButton(JButton button) {
    		button.setBackground(Color.WHITE);
    		button.setForeground(Color.BLACK);
    		button.setFont(new Font("나눔 고딕", Font.BOLD, 30));
    		button.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
    	}
    	
        public void showFirstPage() {
            cardLayout.show(mainPanel, "firstpage");
        }
        
        public void showSecondPage() {
            cardLayout.show(mainPanel, "secondpage");
        }
        
        public void showThirdPage() {
            cardLayout.show(mainPanel, "thirdpage");
        }

        public void stores() {
            // 각 매장의 clickCount 값을 저장할 Map
            Map<String, Integer> storeClickCounts = new HashMap<>();
            
            // 각 매장의 clickCount 값을 Map에 저장
            storeClickCounts.put("나이키", page2panel2.clickCount);
            storeClickCounts.put("난닝구", page2panel3.clickCount);
            storeClickCounts.put("내셔널 지오그래픽", page2panel4.clickCount);
            storeClickCounts.put("뉴발란스", page2panel5.clickCount);
            storeClickCounts.put("디스커버리", page2panel6.clickCount);
            storeClickCounts.put("라코스테", page2panel7.clickCount);
            storeClickCounts.put("무인양품", page2panel8.clickCount);
            storeClickCounts.put("미쏘", page2panel9.clickCount);
            storeClickCounts.put("미니골드", page2panel10.clickCount);
            storeClickCounts.put("바인드", page2panel11.clickCount);
            storeClickCounts.put("반스", page2panel12.clickCount);
            storeClickCounts.put("스파오", page2panel13.clickCount);
            storeClickCounts.put("슈펜", page2panel14.clickCount);
            storeClickCounts.put("아디다스", page2panel15.clickCount);
            storeClickCounts.put("에이치앤엠", page2panel16.clickCount);
            storeClickCounts.put("에잇세컨즈", page2panel17.clickCount);
            storeClickCounts.put("육육걸즈", page2panel18.clickCount);
            storeClickCounts.put("유니클로", page2panel19.clickCount);
            storeClickCounts.put("자라", page2panel20.clickCount);
            storeClickCounts.put("지오다노", page2panel21.clickCount);
            storeClickCounts.put("찰스앤키스", page2panel22.clickCount);
            storeClickCounts.put("칼하트", page2panel23.clickCount);
            storeClickCounts.put("커버낫", page2panel24.clickCount);
            storeClickCounts.put("탑텐", page2panel25.clickCount);

            
            // 상위 3개 매장 선정
            Map<String, Integer> topStores = storeClickCounts.entrySet().stream()
                    .sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue())) // clickCount 내림차순 정렬
                    .limit(5) // 상위 5개 매장만 선택
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new)); // LinkedHashMap으로 변경하여 순서 보장
            
            // leftPanel 초기화
            leftPanel.removeAll();
            
            int labelY = 10;
            int labelHeight = 30;
            for (String brand : topStores.keySet()) {
                JLabel label = new JLabel(brand);
                styleLabel(label); // 라벨 스타일 적용
                label.setPreferredSize(new Dimension(130, labelHeight)); // 라벨 크기 설정
                label.setBounds(0, labelY, 130, labelHeight); // 라벨 위치 설정
                leftPanel.add(label);
                
                // 다음 라벨의 Y 위치 설정
                labelY += labelHeight; // 각 라벨의 높이만큼 간격을 줘서 한 줄에 모두 표시될 수 있도록 함
            }
            
            // leftPanel 업데이트
            leftPanel.revalidate();
            leftPanel.repaint();
        }
        
        private void styleLabel(JLabel label) {
            label.setBackground(Color.WHITE);
            label.setForeground(Color.BLACK);
            label.setFont(new Font("나눔 고딕", Font.BOLD, 11));
            label.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
            label.setOpaque(true);
        }
}