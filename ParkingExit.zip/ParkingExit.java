package 객체지향기말;

import java.util.Scanner;

public class ParkingExit {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("차량번호 4자리를 입력하세요:");

        // 사용자 입력 받기
        String input = scanner.nextLine();

        // 입력된 차량번호가 4자리인지 확인
        if (input.length() == 4 && input.matches("\\d{4}")) {
            System.out.println("출차 완료: 차량번호 " + input);
        } else {
            System.out.println("유효하지 않은 차량번호입니다. 다시 시도해주세요.");
        }

        scanner.close();
    }
}
