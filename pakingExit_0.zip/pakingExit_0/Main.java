package 객체지향기말최종;

import javax.swing.*;

public class Main {
    private static DefaultListModel<String> exitListModel = new DefaultListModel<>();

    public static void main(String[] args) {
        CSVTest.loadDatafromCSV();

        JFrame frame = new JFrame("출차페이지");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000, 1000); // 프레임 크기 조정

        // 배경 이미지 패널
        BackgroundPanel panel = new BackgroundPanel(new ImageIcon("C:\\Users\\sjh35\\eclipse-workspace\\객체지향기말\\background2.png").getImage());
        panel.setLayout(null);

        // 출차된 차량 리스트
        JList<String> exitList = new JList<>(exitListModel);
        JScrollPane scrollPane = new JScrollPane(exitList);
        scrollPane.setBounds(60, 250, 700, 450); // 위치와 크기 조정
        panel.add(scrollPane);

        // 번호 입력 패널 추가
        CarNum numberInputPanel = new CarNum(frame, exitListModel);
        numberInputPanel.setBounds(0, 0, 2000, 1000); // 패널 크기 설정
        panel.add(numberInputPanel);

        frame.add(panel);
        frame.setVisible(true);
    }
}
