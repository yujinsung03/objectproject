package 객체지향기말최종;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class CSVTest {
    private static final String CSV_FILE = "C:\\Users\\sjh35\\eclipse-workspace\\객체지향2024\\bin\\객체지향기말1\\car1.csv";
    private static final Map<String, String> parkingSpots = new HashMap<>();

    public static Map<String, String> getParkingSpots() {
        return parkingSpots;
    }

    public static void loadDatafromCSV() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String carnum = parts[0].trim();
                    String parkingSpot = parts[1].trim();
                    parkingSpots.put(carnum, parkingSpot);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void updateCSVFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE))) {
            for (String key : parkingSpots.keySet()) {
                String value = parkingSpots.get(key);
                writer.write(key + "," + value);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

