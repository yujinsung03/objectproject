package 객체지향기말최종1;

import javax.swing.*;
import java.awt.*;


public class DiscountScreen {
    private JFrame frame;

    public void showScreen() {
        if (frame == null) {
            frame = new JFrame("주차할인 정보");
            frame.setSize(700, 500);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
            frame.setLayout(null); 
            frame.setLocationRelativeTo(null);
            
            JPanel panel = new JPanel();
            panel.setLayout(null);
            panel.setBounds(0, 0, 700, 500);
            
            JLabel titleLabel = new JLabel("주차요금안내");
            titleLabel.setBounds(250, 30, 200, 30);
            titleLabel.setHorizontalAlignment(SwingConstants.CENTER); 
            
            titleLabel.setFont(new Font("나눔바른고딕", Font.BOLD, 25));
            panel.add(titleLabel);

            JLabel feeLabel = new JLabel("* 기본요금: 2,000원/시간 *");
            feeLabel.setBounds(250, 80, 200, 30); // 기본요금의 위치와 크기 설정
            feeLabel.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            panel.add(feeLabel);
            
            JLabel a = new JLabel("*무인정산기: 지하2층/지하1층 주차장*");
            a.setBounds(260, 120, 220, 30); // 기본요금의 위치와 크기 설정
            a.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            panel.add(a);
            
            JLabel b = new JLabel("<html>* 주차할인 3만원이상: 2시간무료 *<br>*     5만원이상: 3시간무료    *<br>*      10만원이상~ : 5시간무료     *<br>  *추가 10분당 1000 *</html>");
            b.setBounds(260,130,200,100);
            b.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            panel.add(b);
            //대중교통이용안내박스
            JPanel box = new JPanel();
            box.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // 네모 테두리 설정
            box.setBounds(35, 250, 280, 130);
            box.setLayout(null);
            panel.add(box);
            
            JPanel blue = new JPanel();
            blue.setBackground(Color.green);
            blue.setBounds(10, 10, 13, 13);
            box.add(blue);
            
            JLabel c = new JLabel("대중교통 이용안내");
            c.setForeground(Color.BLACK);
            c.setFont(new Font("나눔바른고딕", Font.BOLD, 12));
            c.setBounds(30, 3, 120, 30);
            box.add(c);
            
            JPanel cyan = new JPanel();
            cyan.setBackground(Color.CYAN);
            cyan.setBounds(30,40,25,25);
            box.add(cyan);
            
            JLabel d = new JLabel("4");
            d.setForeground(Color.WHITE);
            d.setFont(new Font("나눔바른고딕", Font.BOLD, 13));
            d.setHorizontalAlignment(SwingConstants.CENTER);
            cyan.add(d);
            
            JLabel f = new JLabel("숙대입구역 ");
            f.setBounds(45, 37, 120, 30); // 기본요금의 위치와 크기 설정
            f.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            box.add(f);
            
            JLabel g = new JLabel("1번출구 도보 150m");
            g.setBounds(130, 37, 120, 30); // 기본요금의 위치와 크기 설정
            g.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            box.add(g);
            
            JPanel bl = new JPanel();
            bl.setBackground(Color.BLUE);
            bl.setBounds(30,75,25,25);
            box.add(bl);
            
            JLabel q = new JLabel("1");
            q.setForeground(Color.WHITE);
            q.setFont(new Font("나눔바른고딕", Font.BOLD, 13));
            q.setHorizontalAlignment(SwingConstants.CENTER);
            bl.add(q);
            
            JLabel w = new JLabel("남영역 ");
            w.setBounds(45, 75, 120, 30); // 기본요금의 위치와 크기 설정
            w.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            box.add(w);
            
            JLabel r = new JLabel("2번출구 도보 300m");
            r.setBounds(130, 75, 120, 30); // 기본요금의 위치와 크기 설정
            r.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
            box.add(r);
            
            JPanel dBox = new JPanel();
            dBox.setBorder(BorderFactory.createLineBorder(Color.BLACK)); // 네모 테두리 설정
            dBox.setBounds(330, 250, 280, 130);
            dBox.setLayout(null);
            panel.add(dBox);
            
            JPanel p = new JPanel();
            p.setBackground(Color.yellow);
            p.setBounds(10, 10, 13, 13);
            dBox.add(p);
            

            JLabel dl = new JLabel("할인 가능 매장");
            dl.setForeground(Color.BLACK);
            dl.setFont(new Font("나눔바른고딕", Font.BOLD, 12));
            dl.setBounds(30, 3, 120, 30);
            dBox.add(dl);
            
            JLabel discountLabel = new JLabel("<html>CGV, 롯데시네마, 메가박스,나이키,아디다스,퓨마,미쏘,에잇세컨즈,무인양품,슈펜,탑텐,난닝구,육육걸즈,라코스테,디스커버리</html>");
            //discountLabel.setForeground(Color.BLACK);
            //discountLabel.setFont(new Font("나눔바른고딕", Font.BOLD, 13));
            discountLabel.setBounds(45, 37, 200, 70);
            dBox.add(discountLabel);



            JButton closeButton = new JButton("나가기");
            closeButton.setBounds(280, 420, 150, 25);
            
            closeButton.addActionListener(e -> {
                closeScreen();
            });
            panel.add(closeButton);

            frame.add(panel);
            frame.setVisible(true);
        } else {
            frame.setVisible(true); // 이미 존재하는 경우 화면을 보이게 함
        }
    }

    public void closeScreen() {
        frame.dispose(); // 화면을 닫음
    }
}


