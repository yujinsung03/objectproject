import javax.swing.ImageIcon;
import java.awt.Image;
import java.util.List;

public class EventLoader {
    private EventManager eventManager;

    public EventLoader(EventManager eventManager) {
        this.eventManager = eventManager;
    }

    public ImageIcon loadEvent(int index) {
        Event event = eventManager.getEvent(index);
        ImageIcon icon = new ImageIcon(event.getPath());
        Image image = icon.getImage().getScaledInstance(event.getWidth(), event.getHeight(), Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }

    public String[] getEventPaths() {
        return eventManager.getEventPaths();
    }

    public List<String> getEventDescriptions() {
        return eventManager.getEventDescriptions();
    }

    public int getEventCount() {
        return eventManager.getEvents().size();
    }
}
