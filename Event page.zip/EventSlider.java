import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EventSlider extends JFrame {
    private JLabel imageLabel;
    private JButton startButton;
    private JButton stopButton;
    private JButton nextButton;
    private JButton previousButton;
	private JButton adminButton;
    private JLabel titleLabel1;
    private JLabel titleLabel2;

    private SlideshowController slideshowController;
    private AdminMode adminMode;

    private EventManager eventManager;
    private EventLoader eventLoader;

    public EventSlider() {
        eventManager = new EventManager();
        eventLoader = new EventLoader(eventManager);
        slideshowController = new SlideshowController(this, eventLoader);
        adminMode = new AdminMode(this);

        setTitle("Event Slider");
        setSize(2000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        titleLabel1 = new JLabel("Event");
        titleLabel1.setFont(new Font("Arial", Font.BOLD, 40));
        titleLabel1.setForeground(Color.GRAY);
        titleLabel1.setBounds(180, 80, 200, 75);

        titleLabel2 = new JLabel("이벤트 안내");
        titleLabel2.setFont(new Font("굴림", Font.BOLD, 17));
        titleLabel2.setForeground(Color.GRAY);
        titleLabel2.setBounds(310, 85, 200, 75);

        imageLabel = new JLabel();
        imageLabel.setBounds(165, 150, 1000, 500);

        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        nextButton = new JButton(">");
        previousButton = new JButton("<");
        adminButton = createImageButton("../Images/key.png", 50, 50); 
		
        startButton.setBounds(540, 670, 75, 40);
        stopButton.setBounds(700, 670, 75, 40);
        nextButton.setBounds(1200, 350, 50, 50);
        previousButton.setBounds(75, 350, 50, 50);
        adminButton.setBounds(20, 10, 50, 50);  

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.startSlideshow();
            }
        });

        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.stopSlideshow();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.nextEvent();
            }
        });

        previousButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.previousEvent();
            }
        });

        adminButton.addActionListener(new ActionListener() {  // 관리자 버튼 클릭 이벤트 추가
            @Override
            public void actionPerformed(ActionEvent e) {
                adminMode.showAdminFrame();
            }
        });

        add(titleLabel1);
        add(titleLabel2);
        add(imageLabel);
        add(startButton);
        add(stopButton);
        add(nextButton);
        add(previousButton);
        add(adminButton); 

        slideshowController.loadEvent(0);
        setVisible(true);
    }

    private JButton createImageButton(String imagePath, int width, int height) {
        JButton button = new JButton();
        try {
            ImageIcon icon = new ImageIcon(imagePath);
            Image image = icon.getImage();
            Image resizedImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(resizedImage));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return button;
    }

    public void updateImageLabel(ImageIcon icon) {
        imageLabel.setIcon(icon);
    }

    public int getCurrentEventIndex() {
        return slideshowController.getCurrentEventIndex();
    }

    public void updateEvent(int index, String imagePath, String description) {
        eventManager.updateEvent(index, imagePath, description);
        updateImageLabel(new ImageIcon(imagePath));
        // 설명 업데이트 로직 추가 (필요시)
    }

    public static void main(String[] args) {
        new EventSlider();
    }
}
