import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class AdminMode {
    private EventSlider eventSlider;
    private JFrame adminFrame;
    private JTextField imagePathField;
    private JTextArea descriptionArea;
    private boolean adminAuthenticated = false;

    public AdminMode(EventSlider eventSlider) {
        this.eventSlider = eventSlider;

        adminFrame = new JFrame("관리자 모드");
        adminFrame.setSize(400, 300);
        adminFrame.setLayout(new BorderLayout());

        JPanel adminPanel = new JPanel();
        adminPanel.setLayout(new GridLayout(3, 2));

        JLabel passwordLabel = new JLabel("비밀번호:");
        JPasswordField passwordField = new JPasswordField();
        JButton enterButton = new JButton("입력");

        JLabel imagePathLabel = new JLabel("이미지 경로:");
        imagePathField = new JTextField();

        JButton browseButton = new JButton("찾아보기");

        JLabel descriptionLabel = new JLabel("설명:");
        descriptionArea = new JTextArea();
        JScrollPane descriptionScrollPane = new JScrollPane(descriptionArea);

        adminPanel.add(passwordLabel);
        adminPanel.add(passwordField);
        adminPanel.add(imagePathLabel);
        adminPanel.add(imagePathField);
        adminPanel.add(descriptionLabel);
        adminPanel.add(descriptionScrollPane);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 4)); // 4개의 컬럼으로 수정

        buttonPanel.add(enterButton);
        buttonPanel.add(browseButton);

        JButton uploadButton = new JButton("업로드"); // 새로운 업로드 버튼
        buttonPanel.add(uploadButton); // 업로드 버튼 추가

        JButton closeButton = new JButton("닫기");
        buttonPanel.add(closeButton);

        adminFrame.add(adminPanel, BorderLayout.CENTER);
        adminFrame.add(buttonPanel, BorderLayout.SOUTH);

        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String password = new String(passwordField.getPassword());
                if ("1111".equals(password)) {
                    adminAuthenticated = true;
                    JOptionPane.showMessageDialog(adminFrame, "관리자 인증 완료! 파일을 업로드할 수 있습니다.", "관리자 인증", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(adminFrame, "비밀번호가 올바르지 않습니다.", "오류", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminFrame.setVisible(false);
            }
        });

        browseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (adminAuthenticated) {
                    JFileChooser fileChooser = new JFileChooser();
                    int result = fileChooser.showOpenDialog(adminFrame);
                    if (result == JFileChooser.APPROVE_OPTION) {
                        File selectedFile = fileChooser.getSelectedFile();
                        imagePathField.setText(selectedFile.getAbsolutePath());
                    }
                } else {
                    JOptionPane.showMessageDialog(adminFrame, "관리자 비밀번호를 먼저 입력하세요.", "오류", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (adminAuthenticated) {
                    String imagePath = imagePathField.getText();
                    String description = descriptionArea.getText();
                    int currentEventIndex = eventSlider.getCurrentEventIndex();
                    eventSlider.updateEvent(currentEventIndex, imagePath, description);
                    JOptionPane.showMessageDialog(adminFrame, "파일 업로드 완료!", "업로드", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(adminFrame, "관리자 비밀번호를 먼저 입력하세요.", "오류", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        adminFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        adminFrame.setLocationRelativeTo(null);
    }

    public void showAdminFrame() {
        adminFrame.setVisible(true);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                EventSlider slider = new EventSlider(); // 실제 이벤트 슬라이더 클래스로 대체
                AdminMode adminMode = new AdminMode(slider);
                adminMode.showAdminFrame();
            }
        });
    }
}
