import javax.swing.*;
import java.awt.*;

public class EventPopup extends JFrame {

    public EventPopup(ImageIcon imageIcon) {
        setTitle("Event Popup");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); 
        setSize(400, 150); 

        JLabel imageLabel = new JLabel(imageIcon);
        add(imageLabel, BorderLayout.CENTER);

		JLabel eventInfoLabel = new JLabel("<html><center>행사 장소: 2층 행사장<br>행사 시간: 11:00~ 15:00(소진 시 마감)</center></html>");
        eventInfoLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        eventInfoLabel.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
        add(eventInfoLabel, BorderLayout.SOUTH); 

        setLocationRelativeTo(null); 
        setVisible(true); 
	}
}



