package object8team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Floor3 extends JFrame {
    private CardLayout cardLayout;
    JPanel mainPanel3;
    JPanel buttonPanel;
    private JButton btnFirstFloor, btnSecondFloor, btnThirdFloor;
    private JButton btnRestroom, btnStorage;
    private Timer blinkTimer;
    private boolean isBlinkingRestroom = false;
    private boolean isBlinkingStorage = false;

    public Floor3() {
        setTitle("Floor3");
        setSize(2000, 830);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        menubuttonpanel panelCreator = new menubuttonpanel();
        JPanel menuPanel = panelCreator.createPanel(this);
        setLayout(null);
        menuPanel.setBounds(1290, 0, 250, 1000);
        add(menuPanel);
        
        setLayout(new BorderLayout());
        JLabel headerLabel = new JLabel("Third Floor", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(headerLabel, BorderLayout.NORTH);

        cardLayout = new CardLayout();
        mainPanel3 = new JPanel(cardLayout);

        JPanel mapPanel = createMapPanel();
        mainPanel3.add(mapPanel, "Map");

        addStorePanels();

        add(mainPanel3, BorderLayout.CENTER);
        add(createFloorNavigationPanel(), BorderLayout.SOUTH);

        buttonPanel = new JPanel();
        btnFirstFloor = new JButton("1층");
        btnSecondFloor = new JButton("2층");
        btnThirdFloor = new JButton("3층");
        JButton restroomLocation = new JButton("화장실 위치	1 안내");
        JButton boxLocation = new JButton("물품보관함 위치 안내");

        btnFirstFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Floor1().setVisible(true);
            }
        });

        btnSecondFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Floor2().setVisible(true);
            }
        });

        btnThirdFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Floor3().setVisible(true);
            }
        });

        restroomLocation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startBlinking(btnRestroom, 7);
            }
        });
    

        boxLocation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startBlinking(btnStorage, 7);
            }
        
        });

        buttonPanel.add(btnFirstFloor);
        buttonPanel.add(btnSecondFloor);
        buttonPanel.add(btnThirdFloor);
        buttonPanel.add(restroomLocation);
        buttonPanel.add(boxLocation);

        add(buttonPanel, BorderLayout.SOUTH);
        cardLayout.show(mainPanel3, "Map");
    }
    

    private JPanel createMapPanel() {
        JPanel mapPanel = new JPanel();
        mapPanel.setLayout(null); // Use absolute positioning for custom layout

        // Create buttons for each store
        int buttonSize = 150; // Increased button size
        int spacing = 150; // Adjust spacing
        int offsetX = 300; // Move to the right
        int offsetY = 100; // Move down

        JButton btnZioDano = createCustomButton("지오다노");
        btnZioDano.setBounds(offsetX, offsetY, buttonSize, buttonSize);
        btnZioDano.addActionListener(new StoreButtonListener("ziorDano"));
        applyRollOverEffect(btnZioDano); // Apply dramatic effect
        mapPanel.add(btnZioDano);

        JButton btnCarhartt = createCustomButton("칼하트");
        btnCarhartt.setBounds(offsetX, offsetY + spacing, buttonSize, buttonSize);
        btnCarhartt.addActionListener(new StoreButtonListener("Carhartt"));
        applyRollOverEffect(btnCarhartt); // Apply dramatic effect
        mapPanel.add(btnCarhartt);

        JButton btnSpao = createCustomButton("스파오");
        btnSpao.setBounds(offsetX, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnSpao.addActionListener(new StoreButtonListener("Spao"));
        applyRollOverEffect(btnSpao); // Apply dramatic effect
        mapPanel.add(btnSpao);

        JButton btnVans = createCustomButton("반스");
        btnVans.setBounds(offsetX + spacing, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnVans.addActionListener(new StoreButtonListener("Vans"));
        applyRollOverEffect(btnVans); // Apply dramatic effect
        mapPanel.add(btnVans);

        JButton btnBind = createCustomButton("바인드");
        btnBind.setBounds(offsetX + 2 * spacing, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnBind.addActionListener(new StoreButtonListener("Bind"));
        applyRollOverEffect(btnBind); // Apply dramatic effect
        mapPanel.add(btnBind);

        JButton btnCovernat = createCustomButton("커버낫");
        btnCovernat.setBounds(offsetX + 3 * spacing, offsetY + 2 * spacing, buttonSize, buttonSize);
        btnCovernat.addActionListener(new StoreButtonListener("Covernat"));
        applyRollOverEffect(btnCovernat); // Apply dramatic effect
        mapPanel.add(btnCovernat);

        JButton btnUniqlo = createCustomButton("유니클로");
        btnUniqlo.setBounds(offsetX + 2 * spacing, offsetY, buttonSize, buttonSize);
        btnUniqlo.addActionListener(new StoreButtonListener("Uniqlo"));
        applyRollOverEffect(btnUniqlo); // Apply dramatic effect
        mapPanel.add(btnUniqlo);

        JButton btnCharlesAndKeith = createCustomButton("찰스앤키스");
        btnCharlesAndKeith.setBounds(offsetX + 3 * spacing, offsetY, buttonSize, buttonSize);
        btnCharlesAndKeith.addActionListener(new StoreButtonListener("CharlesAndKeith"));
        applyRollOverEffect(btnCharlesAndKeith); // Apply dramatic effect
        mapPanel.add(btnCharlesAndKeith);

        btnRestroom = createCustomButton("🚻");
        btnRestroom.setBounds(offsetX + 4 * spacing, offsetY, 75, buttonSize); // Adjusted restroom size
        Font buttonFont = btnRestroom.getFont();
        Font newFont = new Font(buttonFont.getName(), buttonFont.getStyle(), 40);
        btnRestroom.setFont(newFont);
        btnRestroom.addActionListener(new StoreButtonListener("Restroom"));
        applyRollOverEffect(btnRestroom);
        mapPanel.add(btnRestroom);
        
     
        
        // Draw lines to separate the buttons
        int lineThickness = 15; // Increased line thickness
        mapPanel.add(createSeparator(offsetX, offsetY + buttonSize, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX, offsetY + buttonSize + spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + spacing, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 2 * spacing, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 3 * spacing, offsetY + buttonSize + 2 * spacing, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 2 * spacing, offsetY + buttonSize, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 3 * spacing, offsetY + buttonSize, buttonSize, lineThickness));
        mapPanel.add(createSeparator(offsetX + 4 * spacing, offsetY + buttonSize, 50, lineThickness));

        
        setVisible(true);
        return mapPanel;
    }


    private JPanel createFloorNavigationPanel() {
        JPanel floorNavPanel = new JPanel();
        JButton firstFloorBtn = new JButton("1층");
        JButton secondFloorBtn = new JButton("2층");
        JButton thirdFloorBtn = new JButton("3층");

        firstFloorBtn.addActionListener(e -> cardLayout.show(mainPanel3, "Map"));
        secondFloorBtn.addActionListener(e -> new Floor2().setVisible(true));
        thirdFloorBtn.addActionListener(e -> new Floor3().setVisible(true));

        floorNavPanel.add(firstFloorBtn);
        floorNavPanel.add(secondFloorBtn);
        floorNavPanel.add(thirdFloorBtn);

        return floorNavPanel;
    }
    
   	private JPanel createFirstFloorPanel() {
        JPanel panel = new JPanel();
        panel.add(new JLabel("First Floor"));
        return panel;
    }

    private void addStorePanels() {
    	
	  	   ImageIcon ziorImage = new ImageIcon("img/ziordano.png");
	  	   Image img = ziorImage.getImage();
	  	   Image newImg = img.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   ziorImage = new ImageIcon(newImg);
	  	   mainPanel3.add(createStorePanel1(ziorImage, "ziorDano"), "ziorDano");

	  	   
	  	   ImageIcon carharttImage = new ImageIcon("img/carhartt.png");
	  	   Image img2 = carharttImage.getImage();
	  	   Image newImg2 = img2.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   carharttImage = new ImageIcon(newImg2);
	  	   mainPanel3.add(createStorePanel2(carharttImage, "This is 칼하트 store."), "Carhartt");
	 
	  	   
	  	   ImageIcon spaoImage = new ImageIcon("img/spao.png");
	  	   Image img3 = spaoImage.getImage();
	  	   Image newImg3 = img3.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   spaoImage = new ImageIcon(newImg3);
	  	   mainPanel3.add(createStorePanel3(spaoImage, "This is SPAO store."), "Spao");
	  	  
	  	   
	  	   ImageIcon vansImage = new ImageIcon("img/vans.png");
	  	   Image img4 = vansImage.getImage();
	  	   Image newImg4 = img4.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   vansImage = new ImageIcon(newImg4);
	  	   mainPanel3.add(createStorePanel4(vansImage, "This is 반스 store."), "Vans");
	  	   
	  	   ImageIcon bindImage = new ImageIcon("img/bind.png");
	  	   Image img5 = bindImage.getImage();
	  	   Image newImg5 = img5.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   bindImage = new ImageIcon(newImg5);
	  	   mainPanel3.add(createStorePanel5(bindImage, "This is 바인드 store."), "Bind");
	  	   
	  	   ImageIcon covernatImage = new ImageIcon("img/covernat.png");
	  	   Image img6 = covernatImage.getImage();
	  	   Image newImg6 = img6.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   covernatImage = new ImageIcon(newImg6);
	  	   mainPanel3.add(createStorePanel6(covernatImage, "This is 커버낫 store."), "Covernat");
	  	   
	  	   ImageIcon uniImage = new ImageIcon("img/uniqlo.png");
	  	   Image img7 = uniImage.getImage();
	  	   Image newImg7 = img7.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   uniImage = new ImageIcon(newImg7);
	  	   mainPanel3.add(createStorePanel7(uniImage, "This is 유니클로 store."), "Uniqlo");
	  	   
	  	   ImageIcon charImage = new ImageIcon("img/charles.png");
	  	   Image img8 = charImage.getImage();
	  	   Image newImg8 = img8.getScaledInstance(650, 450, Image.SCALE_SMOOTH);
	  	   charImage = new ImageIcon(newImg8);
	  	  mainPanel3.add(createStorePanel8(charImage, "This is 찰스앤키스 store."), "CharlesAndKeith");
	  	   
	  }
	
	  private JPanel createStorePanel1(ImageIcon ziorImage, String str1) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel(ziorImage));
	      
	      JButton ziorButton = new JButton("매장 정보 바로가기");
	  	   panel.add(ziorButton, "매장 정보 바로가기");

	  	 ziorButton.addActionListener(new ActionListener() {
  		      private page2frame frame;

			@Override
  		      public void actionPerformed(ActionEvent e) {
  		    	Giordano panel = new Giordano(null);
  		        showPanelInDialog(panel, "매장 설명");
  		      }
			
		    private void showPanelInDialog(JPanel panel, String title) {
		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
		        dialog.getContentPane().add(panel);
		        dialog.setSize(850, 550);
		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
		        dialog.setVisible(true);
		    }
			
  		  });
           return panel;
       }
	  
	  private JPanel createStorePanel2(ImageIcon carharttImage, String str2) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel(carharttImage));
	      
	      JButton carButton = new JButton("매장 정보 바로가기");
	  	   panel.add(carButton, "매장 정보 바로가기");

	  	 carButton.addActionListener(new ActionListener() {
  		      private page2frame frame;

			@Override
  		      public void actionPerformed(ActionEvent e) {
  		    	Carhartt panel = new Carhartt(null);
  		        showPanelInDialog(panel, "매장 설명");
  		      }
			
		    private void showPanelInDialog(JPanel panel, String title) {
		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
		        dialog.getContentPane().add(panel);
		        dialog.setSize(850, 550);
		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
		        dialog.setVisible(true);
		    }
			
  		  });
           return panel;
       }
	  
	  private JPanel createStorePanel3(ImageIcon spaoImage, String str3) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel(spaoImage));
	  
	  	   JButton spaoButton = new JButton("매장 정보 바로가기");
	  	   panel.add(spaoButton, "매장 정보 바로가기");

	  	   spaoButton.addActionListener(new ActionListener() {
	   		      private page2frame frame;

	  			@Override
	     		      public void actionPerformed(ActionEvent e) {
	     		    	Spao panel = new Spao(null);
	     		        showPanelInDialog(panel, "매장 설명");
	     		      }
	  			
	  		    private void showPanelInDialog(JPanel panel, String title) {
	  		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
	  		        dialog.getContentPane().add(panel);
	  		        dialog.setSize(850, 550);
	  		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
	  		        dialog.setVisible(true);
	  		    }
	  			
	     		  });
	              return panel;
	          }
	  
	  private JPanel createStorePanel4(ImageIcon vansImage, String str4) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel(vansImage));
	      
	      JButton vansButton = new JButton("매장 정보 바로가기");
	  	   panel.add(vansButton, "매장 정보 바로가기");

	  	 vansButton.addActionListener(new ActionListener() {
  		      private page2frame frame;

			@Override
  		      public void actionPerformed(ActionEvent e) {
  		    	Vans panel = new Vans(null);
  		        showPanelInDialog(panel, "매장 설명");
  		      }
			
		    private void showPanelInDialog(JPanel panel, String title) {
		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
		        dialog.getContentPane().add(panel);
		        dialog.setSize(850, 550);
		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
		        dialog.setVisible(true);
		    }
			
  		  });
           return panel;
       }
	  
	  private JPanel createStorePanel5(ImageIcon bindImage, String str5) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel(bindImage));
	      JButton bindButton = new JButton("매장 정보 바로가기");
	  	   panel.add(bindButton, "매장 정보 바로가기");

	  	 bindButton.addActionListener(new ActionListener() {
  		      private page2frame frame;

			@Override
  		      public void actionPerformed(ActionEvent e) {
  		    	Bind panel = new Bind(null);
  		        showPanelInDialog(panel, "매장 설명");
  		      }
			
		    private void showPanelInDialog(JPanel panel, String title) {
		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
		        dialog.getContentPane().add(panel);
		        dialog.setSize(850, 550);
		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
		        dialog.setVisible(true);
		    }
			
  		  });
           return panel;
       }
	  
	  private JPanel createStorePanel6(ImageIcon covernatImage, String str6) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel(covernatImage));
	      JButton covernatButton = new JButton("매장 정보 바로가기");
	  	  panel.add(covernatButton, "매장 정보 바로가기");

	  	  covernatButton.addActionListener(new ActionListener() {
   		      private page2frame frame;

			@Override
   		      public void actionPerformed(ActionEvent e) {
   		    	Covernat panel = new Covernat(null);
   		        showPanelInDialog(panel, "매장 설명");
   		      }
			
		    private void showPanelInDialog(JPanel panel, String title) {
		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
		        dialog.getContentPane().add(panel);
		        dialog.setSize(850, 550);
		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
		        dialog.setVisible(true);
		    }
			
   		  });
            return panel;
        }
	  
	  private JPanel createStorePanel7(ImageIcon  uniImage, String str7) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel( uniImage));
	      JButton uniButton = new JButton("매장 정보 바로가기");
	  	  panel.add(uniButton, "매장 정보 바로가기");

	  	  uniButton.addActionListener(new ActionListener() {
   		      private page2frame frame;

			@Override
   		      public void actionPerformed(ActionEvent e) {
   		    	Uniqlo panel = new Uniqlo(null);
   		        showPanelInDialog(panel, "매장 설명");
   		      }
			
		    private void showPanelInDialog(JPanel panel, String title) {
		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
		        dialog.getContentPane().add(panel);
		        dialog.setSize(850, 550);
		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
		        dialog.setVisible(true);
		    }
			
   		  });
            return panel;
        }
	  
	  private JPanel createStorePanel8(ImageIcon  charImage, String str7) {
	      JPanel panel = new JPanel();
	      panel.add(new JLabel( charImage));
	      JButton charButton = new JButton("매장 정보 바로가기");
	  	  panel.add(charButton, "매장 정보 바로가기");

	  	charButton.addActionListener(new ActionListener() {
 		      private page2frame frame;

			@Override
 		      public void actionPerformed(ActionEvent e) {
 		    	Charles panel = new Charles(null);
 		        showPanelInDialog(panel, "매장 설명");
 		      }
			
		    private void showPanelInDialog(JPanel panel, String title) {
		        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
		        dialog.getContentPane().add(panel);
		        dialog.setSize(850, 550);
		        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
		        dialog.setVisible(true);
		    }
			
 		  });
          return panel;
      }

    

    private JButton createCustomButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("나눔 고딕", Font.PLAIN, 20));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        return button;
    }

    private void applyRollOverEffect(JButton button) {
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setFont(button.getFont().deriveFont(Font.BOLD, 26f)); // Larger font size for dramatic effect
                button.setBackground(new Color(158, 188, 219)); // Highlight the button
                button.setOpaque(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setFont(button.getFont().deriveFont(Font.PLAIN, 20f)); // Revert font size
                button.setBackground(UIManager.getColor("Button.background")); // Revert button color
                button.setOpaque(false);
            }
        });
    }

    private JLabel createSeparator(int x, int y, int width, int height) {
        JLabel separator = new JLabel();
        separator.setOpaque(true);
        separator.setBackground(Color.BLACK);
        separator.setBounds(x, y, width, height);
        return separator;
    }

    private void startBlinking(JButton button, int times) {
        if (blinkTimer != null && blinkTimer.isRunning()) {
            blinkTimer.stop();
        }

        blinkTimer = new Timer(300, new ActionListener() {
            int count = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                if (count < times) {
                    button.setVisible(!button.isVisible());
                    count++;
                } else {
                    button.setVisible(true);
                    blinkTimer.stop();
                }
            }
        });

        blinkTimer.start();
    }
    
    private void stopBlinking() {
        if (blinkTimer != null && blinkTimer.isRunning()) {
            blinkTimer.stop();
            btnRestroom.setVisible(true); // Ensure button is visible after stopping
            btnStorage.setVisible(true); // Ensure button is visible after stopping
        }
    }

    private class StoreButtonListener implements ActionListener {
        private String storeName;

        public StoreButtonListener(String storeName) {
            this.storeName = storeName;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if ("Restroom".equals(storeName)) {
                if (!isBlinkingRestroom) {
                    startBlinking(btnRestroom, 5); // Start blinking for 5 times
                } else {
                    stopBlinking();
                }
                isBlinkingRestroom = !isBlinkingRestroom;
            } else if ("Storage".equals(storeName)) {
                if (!isBlinkingStorage) {
                    startBlinking(btnStorage, 5); // Start blinking for 5 times
                } else {
                    stopBlinking();
                }
                isBlinkingStorage = !isBlinkingStorage;
            } else {
                cardLayout.show(mainPanel3, storeName);
            }
        }
    
    }
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Floor3 floor3 = new Floor3();
            floor3.setVisible(true);
        });
    }
}


