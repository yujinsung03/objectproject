package object8team;

public class Page4 {
    public static void main(String[] args) {
    	
        ParkingExit.start();
    }
}
