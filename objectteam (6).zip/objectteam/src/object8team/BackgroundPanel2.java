package object8team;

import javax.swing.*;
import java.awt.*;

public class BackgroundPanel2 extends JPanel {
    private Image image;

    public BackgroundPanel2(Image image) {
        this.image = image;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (image != null) {
            g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
