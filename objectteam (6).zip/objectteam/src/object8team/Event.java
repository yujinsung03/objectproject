package object8team;

public class Event {
    private String path;
    private int width;
    private int height;
    private String description;

    public Event(String path, int width, int height, String description) {
        this.path = path;
        this.width = width;
        this.height = height;
        this.description = description;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
