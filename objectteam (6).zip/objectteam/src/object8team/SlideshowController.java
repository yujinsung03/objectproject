package object8team;

import javax.swing.*;
import java.awt.event.*;

class SlideshowController {
    private EventSlider eventSlider;
    private EventLoader eventLoader;
    private Timer timer;

    public SlideshowController(EventSlider eventSlider, EventLoader eventLoader) {
        this.eventSlider = eventSlider;
        this.eventLoader = eventLoader;
    }

    public void startSlideshow() {
        timer = new Timer(2000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nextEvent();
            }
        });
        timer.start();
    }

    public void stopSlideshow() {
        if (timer != null) {
            timer.stop();
        }
    }

    public void nextEvent() {
        int nextIndex = (eventSlider.getCurrentEventIndex() + 1) % eventLoader.getEventCount();
        eventSlider.showEvent(nextIndex);
    }

    public void previousEvent() {
        int prevIndex = (eventSlider.getCurrentEventIndex() - 1 + eventLoader.getEventCount()) % eventLoader.getEventCount();
        eventSlider.showEvent(prevIndex);
    }

    public void loadEvent(int index) {
        eventSlider.showEvent(index);
    }
}
