package object8team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ParkingExit {
    private static final StringBuilder carnum = new StringBuilder();
    private static DefaultListModel<String> exitListModel = new DefaultListModel<>();
    private static DiscountScreen discountScreen = new DiscountScreen();
    
    
    public ParkingExit() {
        start();
    }
    
    public static void start() {
        CSVTest.loadDatafromCSV();

        JFrame frame = new JFrame("출차페이지");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000, 830); // 프레임 크기 조정
        
        //배경이미지
        BackgroundPanel panel = new BackgroundPanel(new ImageIcon("back3.png").getImage());
        panel.setLayout(null);

        JList<String> exitList = new JList<>(exitListModel);
        exitList.setFont(new Font("나눔바른고딕", Font.BOLD, 18)); 
        JScrollPane scrollPane = new JScrollPane(exitList);
        scrollPane.setBounds(120, 280, 600, 405);
        panel.add(scrollPane);

        JLabel numberLabel = new JLabel("차량번호:");
        numberLabel.setBounds(850, 300, 80, 25);
        panel.add(numberLabel);

        JLabel ParkLabel = new JLabel("출차요청");
        ParkLabel.setBounds(940, 190, 220, 45);
        ParkLabel.setFont(new Font("나눔바른고딕", Font.BOLD, 40));
        panel.add(ParkLabel);

        JLabel ParkingLabel = new JLabel("차량번호를 입력하세요");
        ParkingLabel.setBounds(920, 260, 220, 25);
        ParkingLabel.setFont(new Font("나눔바른고딕", Font.BOLD, 18));
        panel.add(ParkingLabel);

        JLabel writenum = new JLabel("");
        writenum.setBounds(910, 300, 170, 25);
        writenum.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.add(writenum);

        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(1080, 300, 80, 25);
        panel.add(clearButton);

        clearButton.addActionListener(e -> {
            carnum.setLength(0);
            writenum.setText("");
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 3, 10, 10));
        buttonPanel.setBounds(860, 350, 280, 300);

        ActionListener numberButtonListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (carnum.length() < 4) {
                    carnum.append(e.getActionCommand());
                    writenum.setText(carnum.toString());
                }
            }
        };

        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(String.valueOf(i));
            button.setFont(new Font("Serif", Font.BOLD, 20));
            button.addActionListener(numberButtonListener);
            buttonPanel.add(button);
        }

        JButton zeroButton = new JButton("0");
        zeroButton.setFont(new Font("Serif", Font.BOLD, 20));
        zeroButton.addActionListener(numberButtonListener);
        buttonPanel.add(zeroButton);

        buttonPanel.add(new JLabel(""));
        buttonPanel.add(new JLabel(""));

        panel.add(buttonPanel);

        JButton searchButton = new JButton("Search");
        searchButton.setBounds(860, 670, 300, 30);
        searchButton.setFont(new Font("Serif", Font.BOLD, 15));
        panel.add(searchButton);

        searchButton.addActionListener(e -> {
            if (carnum.length() == 4) {
                List<String> matchNum = CSVTest.findCar(carnum.toString());
                if (matchNum.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, carnum + " 해당 번호를 찾을 수 없습니다.");
                } else if (matchNum.size() == 1) {
                    String selectedCar = matchNum.get(0);
                    exitCar(selectedCar);
                } else {
                    String selectedCar = chooseCarToExit(matchNum);
                    if (selectedCar != null) {
                        exitCar(selectedCar);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(frame, "4자리번호를 입력하세요");
            }
        });

        JButton exitManagementButton = new JButton("주차할인");
        exitManagementButton.setBounds(630, 750, 140, 30);
        panel.add(exitManagementButton);

        exitManagementButton.addActionListener(e -> {
            
            showDiscountScreen();
        });

        frame.add(panel);
        
        menubuttonpanel panelCreator = new menubuttonpanel();
        JPanel menuPanel = panelCreator.createPanel(frame);
        menuPanel.setBounds(1290, 0, 250, 1000); // 위치 및 크기 설정 (프레임의 오른쪽에 고정)
        panel.add(menuPanel);

        frame.setVisible(true);
    	
    }
   

    private static void exitCar(String car) {
        int response = JOptionPane.showConfirmDialog(null, "차량번호:" + car + " 위치: " + CSVTest.getParkingSpots().get(car) + "가 맞습니까?",
                "", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            removeCar(car);
        }
    }



    private static void removeCar(String car) {
        JOptionPane.showMessageDialog(null, "                  출차완료!\n 차량번호: " + car + " 위치: " + CSVTest.getParkingSpots().get(car));
        exitListModel.addElement(car); // 출차된 차량을 리스트에 추가
        CSVTest.removeCar(car); // 주차 구역 정보에서 제거
        new javax.swing.Timer(5000, e -> exitListModel.removeElement(car)).start();
    
    }

    private static String chooseCarToExit(List<String> matchNum) {
        return (String) JOptionPane.showInputDialog(
                null,
                "출차할 차량을 선택하시오",
                "",
                JOptionPane.QUESTION_MESSAGE,
                null,
                matchNum.toArray(),
                matchNum.get(0)
        );
    }
    private static void showDiscountScreen() {
        if (discountScreen == null) {
            discountScreen = new DiscountScreen();
        }
        discountScreen.showScreen();
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> start());
    }


    static class BackgroundPanel extends JPanel {
        private Image image;

        public BackgroundPanel(Image image) {
            this.image = image;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (image != null) {
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}
