package object8team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class LoginFrame extends JFrame {
    private boolean adminAuthenticated = false;
    private EventSlider eventSlider;

    public LoginFrame(EventSlider eventSlider) {
        this.eventSlider = eventSlider;

        setTitle("로그인");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel loginPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JLabel passwordLabel = new JLabel("비밀번호:");
        JPasswordField passwordField = new JPasswordField(10);
        JButton loginButton = new JButton("로그인");

        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);
        loginPanel.add(loginButton);

        add(loginPanel);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String password = new String(passwordField.getPassword());
                if ("1111".equals(password)) {
                    adminAuthenticated = true;
                    setVisible(false); // 로그인 창 닫기
                    showAdminDialog(); // 관리자 모드 다이얼로그 열기
                } else {
                    JOptionPane.showMessageDialog(LoginFrame.this, "비밀번호가 올바르지 않습니다.", "오류", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        setVisible(true); // 로그인 창 보이기
    }

    public boolean isAdminAuthenticated() {
        return adminAuthenticated;
    }

    private void showAdminDialog() {
        JFrame adminDialog = new JFrame("관리자 모드 설정");
        adminDialog.setSize(400, 250); // 창 크기 조정
        adminDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        adminDialog.setLocationRelativeTo(null);

        JPanel adminPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // 간격 조정

        JLabel imagePathLabel = new JLabel("이미지 경로:");
        JTextField imagePathField = new JTextField(20); // 입력 필드 크기 조정
        JButton browseButton = new JButton("찾아보기");

        JLabel descriptionLabel = new JLabel("설명:");
        JTextArea descriptionArea = new JTextArea(5, 20); // 텍스트 영역 크기 조정
        descriptionArea.setLineWrap(true); // 텍스트 wrapping 활성화
        JScrollPane descriptionScrollPane = new JScrollPane(descriptionArea);

        JButton uploadButton = new JButton("업로드");
        uploadButton.setPreferredSize(new Dimension(100, 30)); // 버튼 크기 조정

        // 찾아보기 버튼 리스너
        browseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(adminDialog);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    imagePathField.setText(selectedFile.getAbsolutePath());
                }
            }
        });

        // 업로드 버튼 리스너
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String imagePath = imagePathField.getText();
                String description = descriptionArea.getText();
                int currentEventIndex = eventSlider.getCurrentEventIndex();
                eventSlider.updateEvent(currentEventIndex, imagePath, description); // updateEvent 호출
                JOptionPane.showMessageDialog(adminDialog, "이벤트 업데이트 완료!", "업로드", JOptionPane.INFORMATION_MESSAGE);
                adminDialog.dispose(); // 다이얼로그 닫기
            }
        });

        // GridBagLayout을 사용하여 각 컴포넌트를 배치
        gbc.gridx = 0;
        gbc.gridy = 0;
        adminPanel.add(imagePathLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        adminPanel.add(imagePathField, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        adminPanel.add(browseButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        adminPanel.add(descriptionLabel, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        adminPanel.add(descriptionScrollPane, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        adminPanel.add(uploadButton, gbc);

        adminDialog.add(adminPanel);
        adminDialog.setVisible(true);
    }
}
