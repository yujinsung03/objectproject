package object8team;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class firstpage extends JPanel{

    public firstpage(page2frame frame) {
        setLayout(null);
        setOpaque(false);

        JButton nextPageButton = new JButton(">");
        nextPageButton.setBounds(1049, 350, 50, 50); // 버튼 위치와 크기 설정
        nextPageButton.addActionListener(e -> frame.showSecondPage());
        add(nextPageButton);
        
        JPanel panel = new page2panel2(frame);
        panel.setBounds(60, 50, 234, 300);

        JPanel panel2 = new page2panel3(frame);
        panel2.setBounds(310, 50, 234, 300);

        JPanel panel3 = new page2panel4(frame);
        panel3.setBounds(560, 50, 234, 300);

        JPanel panel4 = new page2panel5(frame);
        panel4.setBounds(810, 50, 234, 300);

        JPanel panel5 = new page2panel6(frame);
        panel5.setBounds(60, 400, 234, 300);

        JPanel panel6 = new page2panel7(frame);
        panel6.setBounds(310, 400, 234, 300);

        JPanel panel7 = new page2panel8(frame);
        panel7.setBounds(560, 400, 234, 300);

        JPanel panel8 = new page2panel9(frame);
        panel8.setBounds(810, 400, 234, 300);

        setVisible(true);
        
        add(panel);
        add(panel2);
        add(panel3);
        add(panel4);
        add(panel5);
        add(panel6);
        add(panel7);
        add(panel8);

    }
}