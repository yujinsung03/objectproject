package object8team;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;

public class ButtonEvent extends MouseAdapter {
    private final JButton button;
    private Color originalForeground;
    private Color originalBackground;
    private Rectangle originalBounss;
    private final int expansionSize = 20; // Amount by which the button expands
	private Rectangle originalBounds;

    public ButtonEvent(JButton button) {
        this.button = button;
        this.originalForeground = button.getForeground();
        this.originalBackground = button.getBackground();
        this.originalBounds = button.getBounds();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // Store original properties
        originalForeground = button.getForeground();
        originalBackground = button.getBackground();
        originalBounds = button.getBounds();

        // Increase button size
        button.setBounds(
            originalBounds.x - expansionSize / 2,
            originalBounds.y - expansionSize / 2,
            originalBounds.width + expansionSize,
            originalBounds.height + expansionSize
        );

        // Change button color
        button.setForeground(Color.GRAY);
        button.setBackground(new Color(231, 229, 222, 255));

        // Bring the button to the front
        button.getParent().setComponentZOrder(button, 0);
        button.getParent().revalidate();
        button.getParent().repaint();
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // Reset button color and size
        button.setForeground(originalForeground);
        button.setBackground(originalBackground);
        button.setBounds(originalBounds);

        // Reset button Z-order
        button.getParent().setComponentZOrder(button, button.getParent().getComponentCount() - 1);
        button.getParent().revalidate();
        button.getParent().repaint();
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Button Event Test");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(null); // Use absolute positioning for testing

            int buttonSize = 100;
            int spacing = 20;
            int offsetX = 50;
            int offsetY = 50;

            for (int i = 0; i < 5; i++) {
                JButton button = new JButton("Button " + (i + 1));
                button.setBounds(offsetX + i * (buttonSize + spacing), offsetY, buttonSize, buttonSize);
                button.setBackground(Color.WHITE); // Set button background to white
                button.addMouseListener(new ButtonEvent(button));
                frame.add(button);
            }

            frame.setSize(800, 600);
            frame.setVisible(true);
        });
    }
}
