package object8team;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class page2panel25 extends JPanel {
	private page2frame frame;
	ImageIcon img;
	JButton b1 = new JButton("매장 설명");
	JButton b2 = new JButton("약도");
	JLabel label = new JLabel("    탑텐");	
	static int clickCount;
	
	public page2panel25(page2frame frame) {	
		this.frame = frame;
		label.setBounds(0, 220, 234, 50);
		label.setBackground(Color.lightGray);
		label.setOpaque(true);
		add(label);
		
		img = new ImageIcon("Topten.jpg");
		JLabel imgLabel = new JLabel(img);
		imgLabel.setBounds(0, 0, 234, 234);
		add(imgLabel);
		
		setLayout(null);
		
		b1.setBounds(0, 270, 130, 30);
		b2.setBounds(130, 270, 104, 30);
		
		styleButton(b1);
		styleButton(b2);
		
	      b1.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
					clickCount++;
					frame.stores();
					showPanel();
	            }
	        });

	        b2.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                clickCount++;
	                frame.stores();
	            }
	        });
			
			add(b1);
			add(b2);
			
			setBounds(0, 0, img.getIconWidth(), img.getIconHeight() + 50);
			setVisible(true);
		}
		
		private void styleButton(JButton button) {
			button.setBackground(Color.GRAY);
			button.setForeground(Color.WHITE);
			button.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2));
		}
		
	    private void showPanel() {
	        Topten panel = new Topten((thirdpage) frame.panel3);
	        showPanelInDialog(panel, "매장 설명");
	    }

	    private void showPanelInDialog(JPanel panel, String title) {
	        JDialog dialog = new JDialog(frame, title, true); // 모달 다이얼로그
	        dialog.getContentPane().add(panel);
	        dialog.setSize(850, 550);
	        dialog.setLocationRelativeTo(frame); // 부모 창의 가운데에 위치
	        dialog.setVisible(true);
	    }
	}