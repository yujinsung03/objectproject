import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class EventSlider extends JFrame {

	private JLabel imageLabel;
	private JButton startButton;
	private JButton stopButton;
	private JButton nextButton;
	private JButton previousButton;
	private JLabel titleLabel1;
	private JLabel titleLabel2;
	private SlideshowController slideshowController;

	public EventSlider() {
		setTitle("Event Slider");
		setSize(2000, 1000);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setLayout(null);

		titleLabel1 = new JLabel("Event");
        titleLabel1.setFont(new Font("Arial", Font.BOLD, 40));
		titleLabel1.setForeground(Color.GRAY);
        titleLabel1.setBounds(180, 80, 200, 75);

		titleLabel2 = new JLabel("이벤트 안내");
        titleLabel2.setFont(new Font("굴림", Font.BOLD, 17));
		titleLabel2.setForeground(Color.GRAY);
        titleLabel2.setBounds(310, 85, 200, 75);


		imageLabel = new JLabel();
		imageLabel.setBounds(165, 150, 1000, 500);

		startButton = new JButton("Start");
		stopButton = new JButton("Stop");
		nextButton = new JButton(">");
		previousButton = new JButton("<");

		startButton.setBounds(540, 670, 75, 40); 
		stopButton.setBounds(700, 670, 75, 40);
		nextButton.setBounds(1200, 350, 50, 50); 
		previousButton.setBounds(75, 350, 50, 50);

		String[] eventPaths = {
			"../Images/event1.jpg",
			"../Images/event2.jpg",
			"../Images/event3.jpg"
		};
		int eventWidth = 1000;
		int eventHeight = 500;

		EventLoader eventLoader = new EventLoader(eventPaths, eventWidth, eventHeight);
		slideshowController = new SlideshowController(this, eventLoader);

		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				slideshowController.startSlideshow();
			}
		});

		stopButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				slideshowController.stopSlideshow();
			}
		});

		nextButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				slideshowController.nextEvent();
			}
		});

		previousButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				slideshowController.previousEvent();
			}
		});

		add(titleLabel1);
		add(titleLabel2);
        add(imageLabel);
        add(startButton);
        add(stopButton);
        add(nextButton);
        add(previousButton);

        slideshowController.loadEvent(0);
        setVisible(true);
    }

	public void updateImageLabel(ImageIcon icon) {
		imageLabel.setIcon(icon);
	}

	public static void main(String[] args) {
		new EventSlider();
	}
}
