package object8team;

import java.io.*;
import java.util.*;

public class CSVTest {
    private static final String CSV_FILE = "C:\\csvdata\\car3.csv";
    private static final Map<String, String> ParkingSpots = new HashMap<>();

    public static void loadDatafromCSV() {
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String carnum = parts[0].trim();
                    String parkingSpot = parts[1].trim();
                    ParkingSpots.put(carnum, parkingSpot);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void updateCSVFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE))) {
            for (String key : ParkingSpots.keySet()) {
                String value = ParkingSpots.get(key);
                writer.write(key + "," + value);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //ParkingSpots을 반환 이건 현재 주차된 차량의 정보가 담긴맵
    public static Map<String, String> getParkingSpots() {
        return ParkingSpots;
    }
    //car을 ParkingSpots에서 지우고 csv파일 업데이트
    public static void removeCar(String car) {
        ParkingSpots.remove(car);
        updateCSVFile();
    }
    //number 포함하는 모든 차량번호를 찾음
    public static List<String> findCar(String number) {
        List<String> matchNum = new ArrayList<>();
        for (String car : ParkingSpots.keySet()) {
            if (car.contains(number)) {
                matchNum.add(car);
            }
        }
        return matchNum;
    }
}

