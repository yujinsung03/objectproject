package object8team;

import java.awt.*;
import javax.swing.*;
import java.util.Calendar;

class TimerThread extends Thread {
	JLabel timerLabel;

	public TimerThread(JLabel Label) {
		timerLabel = Label;
	}

	public void run() {
		while(true) {
			Calendar time = Calendar.getInstance();
			int hh = time.get(Calendar.HOUR_OF_DAY);
			int am_pm = time.get(Calendar.AM_PM);;
			int mi = time.get(Calendar.MINUTE);
			int sec = time.get(Calendar.SECOND);
			
			String ampm = (am_pm == Calendar.AM) ? "AM" : "PM";
			
			timerLabel.setText(String.format("%s %02d:%02d ", ampm, hh, mi));

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}