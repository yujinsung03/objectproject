package object8team;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class EventSlider extends JFrame {

    private JLabel imageLabel;
    private List<ImageIcon> imageIcons; // 이미지 아이콘을 관리하는 리스트
    private List<String> eventDescriptions; // 각 이미지에 대한 이벤트 설명을 관리하는 리스트

    private JButton startButton;
    private JButton stopButton;
    private JButton nextButton;
    private JButton previousButton;
    private JButton adminButton;

    private SlideshowController slideshowController;
    private LoginFrame loginFrame;

    private EventManager eventManager;
    private EventLoader eventLoader;

    private int currentEventIndex; //현재 이벤트 인덱스를 저장

    public EventSlider() {
        eventManager = new EventManager();
        eventLoader = new EventLoader(eventManager);
        slideshowController = new SlideshowController(this, eventLoader);
        loginFrame = new LoginFrame(this);

        setTitle("page3");
        setSize(2000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // 배경 패널
        BackgroundPanel backgroundPanel = new BackgroundPanel("eventbackground.png");
        setContentPane(backgroundPanel);
        backgroundPanel.setLayout(null);

        // 이미지 슬라이드를 표시하는 JLabel
        imageLabel = new JLabel();
        imageLabel.setBounds(125, 200, 1000, 500);
        backgroundPanel.add(imageLabel);

        // 메뉴 버튼 패널
        menubuttonpanel menuPanelCreator = new menubuttonpanel();
        JPanel menuPanel = menuPanelCreator.createPanel(this);
        menuPanel.setBounds(1280, 0, 250, 1000); 
        backgroundPanel.add(menuPanel);

        // 이미지 아이콘과 이벤트 설명 초기화
        imageIcons = new ArrayList<>();
        eventDescriptions = new ArrayList<>();

        // 이미지와 각각의 이벤트 설명을 리스트로 관리
        List<Event> events = eventManager.getEvents();
        for (int i = 0; i < events.size(); i++) {
            Event event = events.get(i);
            ImageIcon icon = new ImageIcon(event.getPath());
            String description = event.getDescription();

            imageIcons.add(icon); // 이미지 아이콘을 리스트에 추가
            eventDescriptions.add(description); // 이벤트 설명을 리스트에 추가
        }

        imageLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        imageLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // 이미지 클릭 시 현재 이벤트 설명을 보여줌
                String eventDescription = eventDescriptions.get(currentEventIndex);
                new EventTab(eventDescription);
            }
        });

		//버튼 설정
        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        nextButton = new JButton(">");
        previousButton = new JButton("<");
        adminButton = createImageButton("key.png", 50, 50);

        startButton.setBounds(520, 720, 75, 40);
        stopButton.setBounds(680, 720, 75, 40);
        nextButton.setBounds(1160, 350, 50, 50);
        previousButton.setBounds(35, 350, 50, 50);
        adminButton.setBounds(20, 770, 50, 50);

        startButton.setBackground(Color.WHITE);
        stopButton.setBackground(Color.WHITE);
        nextButton.setBackground(Color.WHITE);
        previousButton.setBackground(Color.WHITE);
        adminButton.setBackground(Color.WHITE);

        startButton.setFocusPainted(false);
        stopButton.setFocusPainted(false);
        nextButton.setFocusPainted(false);
        previousButton.setFocusPainted(false);
		
		//버튼이벤트 설정
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.startSlideshow();
            }
        });

        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.stopSlideshow();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.nextEvent();
            }
        });

        previousButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                slideshowController.previousEvent();
            }
        });

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loginFrame.setVisible(true);
            }
        });

        // 버튼들을 배경 패널에 추가
        backgroundPanel.add(startButton);
        backgroundPanel.add(stopButton);
        backgroundPanel.add(nextButton);
        backgroundPanel.add(previousButton);
        backgroundPanel.add(adminButton);

        slideshowController.loadEvent(0);
        setVisible(true);
    }

    private JButton createImageButton(String imagePath, int width, int height) {
        JButton button = new JButton();
        try {
            ImageIcon icon = new ImageIcon(imagePath);
            Image image = icon.getImage();
            Image resizedImage = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(resizedImage));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return button;
    }

    public int getCurrentEventIndex() {
        return currentEventIndex;
    }

    public void setCurrentEventIndex(int currentEventIndex) {
        this.currentEventIndex = currentEventIndex;
    }

    public void updateEvent(int index, String imagePath, String description) {
        eventManager.updateEvent(index, imagePath, description);
        ImageIcon icon = new ImageIcon(imagePath);
        imageIcons.set(index, icon); // 이미지 아이콘을 업데이트
        eventDescriptions.set(index, description); // 이벤트 설명을 업데이트
        showEvent(currentEventIndex); // 변경된 이미지 표시
    }

	public void showEvent(int index) {
		currentEventIndex = index;
		ImageIcon icon = imageIcons.get(index);

		// 원본 이미지 아이콘에서 이미지를 가져와서 1000x500 크기로 조정
		Image image = icon.getImage().getScaledInstance(1000, 500, Image.SCALE_SMOOTH);
		ImageIcon scaledIcon = new ImageIcon(image);

		updateImageLabel(scaledIcon);
	}
    public void updateImageLabel(ImageIcon icon) {
        imageLabel.setIcon(icon);
    }

    public static void main(String[] args) {
        new EventSlider();
    }
}
