import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;

public class ThirdFloorPanel extends JPanel {
    CardLayout cardLayout;
    JPanel mainPanel;

    public ThirdFloorPanel() {
        // CardLayout을 사용하여 패널 전환 구현
        cardLayout = new CardLayout();
        setLayout(cardLayout);

        // 메인 패널 초기화
        mainPanel = new JPanel(new BorderLayout());

        // 헤더 추가 및 텍스트 스타일링
        JLabel header = new JLabel("<html><div style='text-align: center; font-size: 24px; font-weight: bold;'>Third Floor</div></html>", JLabel.CENTER);
        header.setBorder(new EmptyBorder(20, 0, 20, 0)); // 상단과 하단에 패딩 추가
        mainPanel.add(header, BorderLayout.NORTH);

        // 중앙 패널 초기화
        JPanel centerPanel = new JPanel(new GridBagLayout());
        JPanel rightPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new java.awt.Insets(10, 0, 10, 0);
        gbc.anchor = GridBagConstraints.CENTER;

        // 버튼 초기화
        JButton b1 = new JButton("바인드");
        JButton b2 = new JButton("반스");
        JButton b3 = new JButton("스파오");
        JButton b4 = new JButton("유니클로");
        JButton b5 = new JButton("커버낫");
        JButton b6 = new JButton("칼하트");
        JButton b7 = new JButton("지오다노");
        JButton b8 = new JButton("찰스앤키스");
        JButton restroom = new JButton("Restroom");
        JButton now = new JButton("Now");

        // 버튼 크기 설정
        Dimension buttonSize = new Dimension(150, 50); // 모든 버튼의 크기를 동일하게 설정
        b1.setPreferredSize(buttonSize);
        b2.setPreferredSize(buttonSize);
        b3.setPreferredSize(buttonSize);
        b4.setPreferredSize(buttonSize);
        b5.setPreferredSize(buttonSize);
        b6.setPreferredSize(buttonSize);
        b7.setPreferredSize(buttonSize);
        b8.setPreferredSize(buttonSize);
        restroom.setPreferredSize(buttonSize);
        now.setPreferredSize(buttonSize);

        // 버튼 위치 설정
        centerPanel.add(b1, gbc);
        gbc.gridy++;
        centerPanel.add(b2, gbc);
        gbc.gridy++;
        centerPanel.add(b3, gbc);
        gbc.gridy++;
        centerPanel.add(b4, gbc);
        gbc.gridy++;
        centerPanel.add(b5, gbc);
        gbc.gridy++;
        centerPanel.add(b6, gbc);
        gbc.gridy++;
        centerPanel.add(b7, gbc);
        gbc.gridy++;
        centerPanel.add(b8, gbc);

        gbc.gridy = 0;
        rightPanel.add(restroom, gbc);
        gbc.gridy++;
        rightPanel.add(now, gbc);

        // 중앙 패널을 메인 패널에 추가
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(rightPanel, BorderLayout.EAST);

        // 메인 패널을 CardLayout에 추가
        add(mainPanel, "Main");

        // 각 버튼 페이지 패널 추가
        add(new BindPanel(), "바인드");
        add(new VansPanel(), "반스");
        add(new SpaoPanel(), "스파오");
        add(new UniqloPanel(), "유니클로");
        add(new CovernatPanel(), "커버낫");
        add(new CarharttPanel(), "칼하트");
        add(new GiordanoPanel(), "지오다노");
        add(new CharlesAndKeithPanel(), "찰스앤키스");
    

        // 버튼에 액션 리스너 추가
        addNavigationListener(b1, "바인드");
        addNavigationListener(b2, "반스");
        addNavigationListener(b3, "스파오");
        addNavigationListener(b4, "유니클로");
        addNavigationListener(b5, "커버낫");
        addNavigationListener(b6, "칼하트");
        addNavigationListener(b7, "지오다노");
        addNavigationListener(b8, "찰스앤키스");
        addNavigationListener(restroom, "Restroom");
        addNavigationListener(now, "Now");
    }

    private void addNavigationListener(JButton button, String target) {
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(ThirdFloorPanel.this, target);
            }
        });
    }

    private void addMouseEffect(JButton button, Dimension originalSize) {
        Dimension largerSize = new Dimension(originalSize.width + 20, originalSize.height + 20);
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.GREEN);
                button.setPreferredSize(largerSize);
                button.revalidate(); // 크기 변화를 즉시 적용
                button.repaint(); // 색상 변화를 즉시 적용
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(null); // 기본 배경색으로 설정
                button.setPreferredSize(originalSize);
                button.revalidate(); // 크기 변화를 즉시 적용
                button.repaint(); // 색상 변화를 즉시 적용
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Third Floor Panel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000, 1000);
        frame.add(new ThirdFloorPanel());
        frame.setVisible(true);
    }
}
