import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;

    public MainFrame() {
        setTitle("Building Floors");
        setSize(2000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // 각 층의 패널을 생성
        FirstFloorPanel firstFloorPanel = new FirstFloorPanel();
        SecondFloorPanel secondFloorPanel = new SecondFloorPanel();
        ThirdFloorPanel thirdFloorPanel = new ThirdFloorPanel();

        // 메인 패널에 각 층 패널 추가
        mainPanel.add(firstFloorPanel, "First Floor");
        mainPanel.add(secondFloorPanel, "Second Floor");
        mainPanel.add(thirdFloorPanel, "Third Floor");

        // 버튼 패널 생성
        JPanel buttonPanel = new JPanel();
        JButton btnFirstFloor = new JButton("1층");
        JButton btnSecondFloor = new JButton("2층");
        JButton btnThirdFloor = new JButton("3층");

        // 버튼에 이벤트 리스너 추가
        btnFirstFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "First Floor");
            }
        });

        btnSecondFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Second Floor");
            }
        });

        btnThirdFloor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "Third Floor");
            }
        });

        // 버튼 패널에 버튼 추가
        buttonPanel.add(btnFirstFloor);
        buttonPanel.add(btnSecondFloor);
        buttonPanel.add(btnThirdFloor);

        // 메인 프레임에 버튼 패널과 메인 패널 추가
        add(buttonPanel, "South");
        add(mainPanel, "Center");

        // 초기 화면 설정
        cardLayout.show(mainPanel, "First Floor");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }
}
