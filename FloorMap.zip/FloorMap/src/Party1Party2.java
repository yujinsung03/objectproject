import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Party1Party2 extends JFrame {
    JButton b1;
    JButton b2;
    Container pane;

    public Party1Party2() {
        // 프레임 설정
        setTitle("Party1Party2");
        setSize(2000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new FlowLayout());

        // 버튼 초기화 및 컨테이너에 추가
        b1 = new JButton("Button 1");
        b2 = new JButton("Button 2");
        pane = getContentPane();
        pane.add(b1);
        pane.add(b2);

        // 버튼 크기 지정
        Dimension originalSize = b1.getPreferredSize();
        Dimension largerSize = new Dimension(originalSize.width + 20, originalSize.height + 20);

        // b1에 마우스 리스너 추가
        b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b1.setBackground(Color.GREEN);
                b1.setPreferredSize(largerSize);
                b1.revalidate(); // 버튼 크기를 즉시 적용
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                b1.setBackground(UIManager.getColor("control"));
                b1.setPreferredSize(originalSize);
                b1.revalidate(); // 버튼 크기를 즉시 적용
            }
        });

        // b2에 마우스 리스너 추가
        b2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b2.setBackground(Color.GREEN);
                b2.setPreferredSize(largerSize);
                b2.revalidate(); // 버튼 크기를 즉시 적용
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                b2.setBackground(UIManager.getColor("control"));
                b2.setPreferredSize(originalSize);
                b2.revalidate(); // 버튼 크기를 즉시 적용
            }
        });
    }

    public static void main(String[] args) {
        // Event Dispatch Thread에서 실행
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Party1Party2().setVisible(true);
            }
        });
    }
}
