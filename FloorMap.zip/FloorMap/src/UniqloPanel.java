import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UniqloPanel extends JPanel {
    public UniqloPanel() {
        setLayout(new BorderLayout());
        JLabel label = new JLabel("유니클로 페이지", JLabel.CENTER);
        JButton backButton = new JButton("이전 페이지로");

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cardLayout = (CardLayout) getParent().getLayout();
                cardLayout.show(getParent(), "Main");
            }
        });

        add(label, BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);
    }
}
