import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import javax.swing.border.EmptyBorder;

public class FirstFloorPanel extends JPanel {
    JButton b1, b2, b3, b4, b5, b6, b7, b8, restroom, now;
    ImageIcon restroomIcon;

    public FirstFloorPanel() {
        // 패널 초기화
        setLayout(new BorderLayout());

        // 헤더 추가 및 텍스트 스타일링
        JLabel header = new JLabel("<html><div style='text-align: center; font-size: 24px; font-weight: bold;'>First Floor</div></html>", JLabel.CENTER);
        header.setBorder(new EmptyBorder(20, 0, 20, 0)); // 상단과 하단에 패딩 추가
        add(header, BorderLayout.NORTH);

        // 중앙 패널 초기화
        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new java.awt.Insets(10, 0, 10, 0);
        gbc.anchor = GridBagConstraints.CENTER;

        // 버튼 초기화
        b1 = new JButton("난닝구");
        b2 = new JButton("육육걸즈");
        b3 = new JButton("무인양품");
        b4 = new JButton("미쏘");
        b5 = new JButton("미니골드");
        b6 = new JButton("에잇세컨즈");
        b7 = new JButton("에이치앤엠");
        b8 = new JButton("슈펜");
        
        
        restroom = new JButton("Restroom");
        now = new JButton("Now");

        // 버튼 크기 설정
        Dimension buttonSize = new Dimension(150, 50); // 모든 버튼의 크기를 동일하게 설정
        b1.setPreferredSize(buttonSize);
        b2.setPreferredSize(buttonSize);
        b3.setPreferredSize(buttonSize);
        b4.setPreferredSize(buttonSize);
        b5.setPreferredSize(buttonSize);
        b6.setPreferredSize(buttonSize);
        b7.setPreferredSize(buttonSize);
        b8.setPreferredSize(buttonSize);
        restroom.setPreferredSize(buttonSize);
        now.setPreferredSize(buttonSize);

        // 버튼 위치 설정
        centerPanel.add(b1, gbc);
        gbc.gridy++;
        centerPanel.add(b2, gbc);
        gbc.gridy++;
        centerPanel.add(b3, gbc);
        gbc.gridy++;
        centerPanel.add(b4, gbc);
        gbc.gridy++;
        centerPanel.add(b5, gbc);
        gbc.gridy++;
        centerPanel.add(b6, gbc);
        gbc.gridy++;
        centerPanel.add(b7, gbc);
        gbc.gridy++;
        centerPanel.add(b8, gbc);
        gbc.gridy++;
        centerPanel.add(restroom, gbc);
        gbc.gridy++;
        centerPanel.add(now, gbc);

        // 중앙 패널을 메인 패널에 추가
        add(centerPanel, BorderLayout.CENTER);

        // 마우스 효과 추가
        addMouseEffect(b1, buttonSize);
        addMouseEffect(b2, buttonSize);
        addMouseEffect(b3, buttonSize);
        addMouseEffect(b4, buttonSize);
        addMouseEffect(b5, buttonSize);
        addMouseEffect(b6, buttonSize);
        addMouseEffect(b7, buttonSize);
        addMouseEffect(b8, buttonSize);
        addMouseEffect(restroom, buttonSize);
        addMouseEffect(now, buttonSize);
    }

    private void addMouseEffect(JButton button, Dimension originalSize) {
        Dimension largerSize = new Dimension(originalSize.width + 20, originalSize.height + 20);
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(Color.GREEN);
                button.setPreferredSize(largerSize);
                button.revalidate(); // 크기 변화를 즉시 적용
                button.repaint(); // 색상 변화를 즉시 적용
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(null); // 기본 배경색으로 설정
                button.setPreferredSize(originalSize);
                button.revalidate(); // 크기 변화를 즉시 적용
                button.repaint(); // 색상 변화를 즉시 적용
            }
        });
    }
}
