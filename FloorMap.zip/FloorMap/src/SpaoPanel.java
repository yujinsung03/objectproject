import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SpaoPanel extends JPanel {
    public SpaoPanel() {
        setLayout(new BorderLayout());
        JLabel label = new JLabel("스파오 페이지", JLabel.CENTER);
        JButton backButton = new JButton("이전 페이지로");

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cardLayout = (CardLayout) getParent().getLayout();
                cardLayout.show(getParent(), "Main");
            }
        });

        add(label, BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);
    }
}
